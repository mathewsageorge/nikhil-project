"""SQLite persistence. Store money as integer paise, never floating totals."""
from contextlib import contextmanager
from datetime import date
from decimal import Decimal
from pathlib import Path
import sqlite3
import pandas as pd
from nlp import validate_entry

DB_PATH = Path(__file__).resolve().parent / 'data' / 'expenses.db'


@contextmanager
def connection(path=DB_PATH):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def init_db(path=DB_PATH):
    with connection(path) as conn:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            intent TEXT NOT NULL CHECK(intent IN ('Expense','Income','Reminder')),
            amount_paise INTEGER NOT NULL CHECK(amount_paise > 0),
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            paid INTEGER NOT NULL DEFAULT 0 CHECK(paid IN (0,1)),
            source_reminder_id INTEGER UNIQUE REFERENCES entries(id),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS budgets (
            month TEXT PRIMARY KEY,
            amount_paise INTEGER NOT NULL CHECK(amount_paise >= 0)
        );
        ''')


def paise(amount):
    return int(Decimal(str(amount)) * 100)


def save_entry(entry, entry_id=None, path=DB_PATH):
    errors = validate_entry(entry)
    if errors:
        raise ValueError(' '.join(errors))
    values = (entry['intent'], paise(entry['amount']), entry['date'].isoformat(),
              entry['description'].strip(), entry['category'])
    with connection(path) as conn:
        if entry_id is None:
            return conn.execute('INSERT INTO entries(intent,amount_paise,date,description,category) VALUES (?,?,?,?,?)', values).lastrowid
        existing = conn.execute('SELECT * FROM entries WHERE id=?', (entry_id,)).fetchone()
        if existing is None:
            raise ValueError('Entry no longer exists.')
        if existing['paid'] or existing['source_reminder_id'] is not None:
            raise ValueError('Paid reminders and their linked expenses are locked. Delete the linked expense to reopen the reminder first.')
        conn.execute('UPDATE entries SET intent=?,amount_paise=?,date=?,description=?,category=? WHERE id=?', values + (entry_id,))
        return entry_id


def list_entries(path=DB_PATH):
    with connection(path) as conn:
        frame = pd.read_sql_query('SELECT * FROM entries ORDER BY date DESC, id DESC', conn)
    frame['amount'] = frame['amount_paise'] / 100
    return frame


def delete_entry(entry_id, path=DB_PATH):
    with connection(path) as conn:
        row = conn.execute('SELECT * FROM entries WHERE id=?', (entry_id,)).fetchone()
        if row:
            if row['source_reminder_id'] is not None:
                conn.execute('UPDATE entries SET paid=0 WHERE id=?', (row['source_reminder_id'],))
            # Deleting a paid reminder preserves the real expense but unlinks it.
            conn.execute('UPDATE entries SET source_reminder_id=NULL WHERE source_reminder_id=?', (entry_id,))
            conn.execute('DELETE FROM entries WHERE id=?', (entry_id,))


def mark_paid(entry_id, payment_date=None, path=DB_PATH):
    """Record one actual expense and mark paid atomically; repeated clicks do nothing."""
    with connection(path) as conn:
        conn.execute('BEGIN IMMEDIATE')
        row = conn.execute('SELECT * FROM entries WHERE id=?', (entry_id,)).fetchone()
        if row is None or row['intent'] != 'Reminder':
            raise ValueError('Select an existing reminder.')
        if row['paid']:
            return False
        conn.execute('''INSERT INTO entries(intent,amount_paise,date,description,category,source_reminder_id)
                        VALUES ('Expense',?,?,?,?,?)''',
                     (row['amount_paise'], (payment_date or date.today()).isoformat(),
                      row['description'], row['category'], entry_id))
        conn.execute('UPDATE entries SET paid=1 WHERE id=?', (entry_id,))
        return True


def set_budget(month, amount, path=DB_PATH):
    import re
    if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', month):
        raise ValueError('Use YYYY-MM for the budget month.')
    value = Decimal(str(amount))
    if not value.is_finite() or value < 0 or value > Decimal('1000000000') or value != value.quantize(Decimal('.01')):
        raise ValueError('Budget must be a valid non-negative amount with at most two decimals.')
    with connection(path) as conn:
        conn.execute('INSERT INTO budgets VALUES (?,?) ON CONFLICT(month) DO UPDATE SET amount_paise=excluded.amount_paise', (month, paise(amount)))


def get_budget(month, path=DB_PATH):
    with connection(path) as conn:
        row = conn.execute('SELECT amount_paise FROM budgets WHERE month=?', (month,)).fetchone()
    return row[0] / 100 if row else 0.0


def monthly_summary(frame, month):
    selected = frame[frame.date.str.startswith(month)]
    income = int(selected.loc[selected.intent == 'Income', 'amount_paise'].sum()) / 100
    expense = int(selected.loc[selected.intent == 'Expense', 'amount_paise'].sum()) / 100
    return income, expense


def reminder_status(row, today=None):
    if row['paid']:
        return 'Paid'
    due = date.fromisoformat(row['date'])
    today = today or date.today()
    return 'Overdue' if due < today else 'Due today' if due == today else 'Upcoming'
