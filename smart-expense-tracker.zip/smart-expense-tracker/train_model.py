"""Train a small, fully local category classifier. No model downloads."""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_score

ROOT = Path(__file__).resolve().parent
DATASET_PATH = ROOT / 'data' / 'training.csv'
MODEL_PATH = ROOT / 'models' / 'category_model.joblib'
CATEGORIES = ['Food', 'Transport', 'Shopping', 'Utilities', 'Rent',
              'Healthcare', 'Education', 'Entertainment', 'Salary', 'Other']


def train_model(model_path=MODEL_PATH, evaluate=False):
    data = pd.read_csv(DATASET_PATH)
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(lowercase=True, stop_words='english',
                                 ngram_range=(1, 2), sublinear_tf=True)),
        ('classifier', LogisticRegression(max_iter=1000, C=4, random_state=42)),
    ])
    if evaluate:
        folds = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
        scores = cross_val_score(pipeline, data.description, data.category, cv=folds)
        print(f'3-fold stratified accuracy: {scores.mean():.1%} (small teaching dataset)')
    pipeline.fit(data.description, data.category)
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, model_path)
    return pipeline


def load_model():
    # Load only this project's trusted local artifact; joblib files execute code.
    return joblib.load(MODEL_PATH) if MODEL_PATH.exists() else train_model()


if __name__ == '__main__':
    train_model(evaluate=True)
    print(f'Saved model: {MODEL_PATH}')
