# Beginner Windows guide - no commands to type

## Run the app on Windows

A simple guide for your friend. No coding or commands to type. Use a Windows 10 or 11 laptop and keep the internet connected for the first setup.

### 1. Save and extract the project

Download smart-expense-tracker.zip from the link shared with you. Open Downloads, right-click the ZIP, and choose Extract All. Click Extract.

Open the extracted folder. If another folder called smart-expense-tracker is inside, open that too. You are in the right place when app.py, SETUP_WINDOWS.bat, and START_WINDOWS.bat are visible together.

Keep this folder on your laptop. Do not open the app directly from inside the ZIP. Do not move individual files out of the folder.

### 2. Install the Python manager once

Open Chrome or Edge and visit: https://www.python.org/downloads/windows/

Near the top, find Latest Python install manager. Under that manager, click Installer (MSIX). Open the downloaded file and click Install. Wait for installation to finish, then close the installer.

Choose the Python install manager, not the separate latest Python 3 release. The project setup file will choose the Python version it needs for you.

### 3. Set up the project once

Return to the project folder. Double-click SETUP_WINDOWS.bat. If Windows hides the ending, its name may appear as SETUP_WINDOWS and its type as Windows Batch File.

A black window will open and show text. This is normal. It installs the required Python version if needed, installs the project packages, prepares the app, and checks that it works. Keep internet connected and leave this window open until it finishes.

Wait until the window says: Setup complete. Double-click START_WINDOWS.bat to open the app. Press any key if the window asks you to. You only need this setup step the first time.

If you see Setup stopped because a command failed, do not continue. Take a screenshot of that window and send it to the person who gave you the project.

## Open it, use it, and close it

### 4. Open the app

In the same project folder, double-click START_WINDOWS.bat. Another black window opens. Keep it open while you use the app.

Your browser may open automatically. If it does not, open Chrome or Edge, click the address bar at the top, type the address below, and press Enter:

`http://127.0.0.1:8501`

If the black window asks for an email address, leave it blank and press Enter. The app does not need your email.

### 5. Add your first expense

In the entry box at the top of the app, type: Spent Rs 300 on pizza today. Click Extract details. Check the amount, date, and category. Click Save transaction. You can use Rs instead of the rupee symbol.

History shows your saved transactions. Edit opens a small pop-up to change an entry. Bill reminders shows bills waiting to be paid. Monthly plan lets you set your budget.

### 6. Close the app

When finished, close the browser tab. Return to the black app window and press Ctrl+C: hold Ctrl and press C. If Windows asks Terminate batch job (Y/N)?, type Y and press Enter. Then close the window.

### Next time: just double-click START_WINDOWS.bat

You do not need to reinstall Python or run setup each day. After the first successful setup, the app works without internet. Saved records stay on this laptop when you close and reopen the app. Reminders appear only while the app is open.

### If something does not open

Cannot see SETUP_WINDOWS? Make sure you extracted the ZIP and opened its inner project folder. Python not found? Restart the laptop after installing the manager, then try setup again. Browser says cannot connect? Check that the black app window is still open and that you used START_WINDOWS, not SETUP_WINDOWS.

If an error remains, take a screenshot of the black window and share it with the project owner. Keep the data folder safe: it contains your saved records. Do not delete it to fix a setup problem.

Sources: Python Windows downloads and installation documentation at https://www.python.org/downloads/windows/ and https://docs.python.org/3/using/windows.html. Checked 12 October 2026. The Windows scripts were reviewed here; the actual Windows check runs during setup on your laptop.
