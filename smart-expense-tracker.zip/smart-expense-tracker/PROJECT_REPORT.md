# Smart Expense Tracker and Bill Reminder Using Natural Language Processing

Student: [Student name]  
College: [College or university name]

## Abstract

This project implements a local personal finance application that accepts one natural-language transaction or bill reminder at a time. It extracts intent, monetary amount, date, description, and category, then presents editable fields before saving. The purpose is to reduce repetitive entry while keeping the user responsible for reviewing financial records.

The implementation combines regular expressions and keyword rules with dateparser for dates. A scikit-learn Pipeline converts descriptions to TF-IDF features and classifies them with Logistic Regression. SQLite persists transactions, reminders, and monthly budgets. Streamlit provides the interface, while pandas and Plotly support summaries and charts. No external AI service, pretrained language model, GPU, or API key is required. The application operates offline once its Python dependencies are installed.

The expanded corpus contains 400 training descriptions and 100 separate evaluation descriptions across ten balanced categories. The trained classifier correctly categorised 98 of the 100 evaluation descriptions, with macro F1 of 0.980. The earlier 150-example model scored 88 of 100 on the same evaluation set. Three-fold cross-validation on the expanded training set achieved 91.7% accuracy. These measurements describe a small synthetic teaching corpus and do not establish real-world financial classification accuracy.

All 85 automated tests passed. They cover required acceptance sentences, ambiguous or invalid input, calendar boundaries, persistence, budget logic, payment idempotency, and Streamlit workflows. The application displays reminders in its running interface and creates one linked expense when a reminder is marked paid. It does not send background mobile or email notifications.

### Keywords

Natural language processing, expense tracking, bill reminders, TF-IDF, Logistic Regression, Streamlit, SQLite, offline application.

### Submission details

Replace the placeholders on the cover before submission. The report describes the delivered implementation and its measured results. Institution-specific certificates, declarations, and signatures should follow the college template and be completed by the appropriate people.

## Contents

| Section | Page |
| --- | --- |
| Introduction and problem definition | 4 |
| Requirements and proposed system | 5 |
| Architecture and modules | 6 |
| Rule based NLP extraction | 7 |
| Machine learning pipeline | 8 |
| Dataset and evaluation protocol | 9 |
| Database design and consistency | 10 |
| Interface and reminder workflow | 11 |
| Testing and acceptance criteria | 12 |
| Experimental results and error analysis | 13 |
| Application screenshots | 14 |
| Installation limitations and conclusion | 15 |
| References and reproducibility | 16 |

The editable Word report uses fixed chapter starts. Update this contents page if you add, remove, or substantially expand chapters.

### Abbreviations

| Term | Meaning |
| --- | --- |
| NLP | Natural Language Processing |
| TF-IDF | Term Frequency Inverse Document Frequency |
| ML | Machine Learning |
| CRUD | Create Read Update Delete |
| INR | Indian Rupee |
| CSV | Comma Separated Values |
| F1 | Harmonic mean of precision and recall |

## Introduction and problem definition

### Problem statement

A student may pay for lunch, travel, books, rent, and utilities on different days. If these payments remain in memory or scattered notes, monthly spending becomes difficult to reconstruct. A missed electricity or internet payment can also go unnoticed until its due date has passed. The problem is therefore both recording daily activity and keeping unpaid obligations visible.

Conventional entry requires users to choose a type, enter an amount, select a date, write a description, and choose a category. The project explores whether a short English sentence can supply useful initial values for those fields. Because everyday language can be ambiguous, automatic extraction must be followed by a review stage rather than an immediate database write.

### Existing manual method

A notebook is accessible but requires manual totals and searching. A spreadsheet supports formulas and charts, yet the user must still maintain categories, dates, and bill status. Both approaches can work well when maintained carefully. The proposed application reduces repeated field entry and keeps reminders beside the transaction history.

### Objectives

- Extract expense, income, and reminder intents from supported English phrases.
- Recognise INR amounts and supported absolute or relative dates.
- Predict one of ten categories using a locally trained classifier.
- Require review and validation before persisting an entry.
- Maintain editable history, bill status, monthly budgets, and spending summaries.
- Support reproducible training, separate evaluation, automated testing, and CSV export.

### Project scope

The system is a single-user local teaching application. It records financial information but does not move money, connect to a bank, verify an actual payment, or provide financial advice. “Mark as paid” changes the local record only. The user remains responsible for making the real payment separately.

## Requirements and proposed system

### Functional requirements

| Area | Required behaviour |
| --- | --- |
| Input | Accept one transaction or reminder sentence and extract candidate fields. |
| Review | Provide editable intent, amount, date, description, and category. |
| Validation | Reject unknown intent, invalid amount, and missing or invalid dates. |
| History | List, edit, and delete saved income, expenses, and reminders. |
| Reminders | Show overdue, due-today, upcoming, and paid bills. |
| Analysis | Show monthly totals, category spending, and income versus expense. |
| Budget and export | Persist monthly budgets, warn on overspending, export all history to CSV. |

### Nonfunctional requirements

Processing and storage must remain local after package installation. The application must not depend on an external AI API, API key, GPU, transformer, large language model, Ollama runtime, or downloaded pretrained model. Code should remain readable enough for a student to explain. Persistence should survive server restarts, and invalid input should produce a correction path rather than a silent save.

### Technology and environment

| Technology | Role |
| --- | --- |
| Python and Streamlit | Application logic and browser interface |
| pandas and Plotly | Data summaries and charts |
| scikit-learn and joblib | Train and persist the category Pipeline |
| Regular expressions and dateparser | Intent, amount, and date extraction |
| SQLite and pytest | Persistent storage and automated verification |

Verification used Python 3.9.6 on macOS Apple Silicon. The exact tested package versions appear in requirements-lock.txt. A CPU is sufficient, and SQLite is included with Python. Installation requires access to a Python package source, while ordinary application operation does not.

## Architecture and modules

The application follows a layered design. The interface asks the NLP module for suggested values, displays them for review, and calls the persistence layer only after validation. Analysis reads the same SQLite records to keep history and monthly summaries consistent.

| Layer | Module | Responsibility |
| --- | --- | --- |
| Presentation | app.py | Input forms, editable preview, history, reminders, charts, export |
| Extraction | nlp.py | Intent, amount, date, description, category suggestion, validation |
| Training | train_model.py | Fit the TF-IDF Pipeline on training.csv and save joblib |
| Evaluation | evaluate_model.py | Audit the split and score a frozen model without fitting |
| Persistence | database.py | Schema, CRUD, budgets, payment transactions, monthly totals |
| Verification | tests directory | NLP, evaluation, database, and Streamlit workflow tests |

### Data flow

- The user enters a single sentence in the Add entry tab.
- Rules extract intent, amount, and supported date expressions.
- Description cleanup removes recognised amounts, dates, and common action phrases.
- The saved Pipeline predicts a category from the cleaned description.
- The user reviews and edits the candidate fields.
- Shared validation checks the reviewed values before SQLite insertion.
- History, reminders, charts, and export read the stored records.

### Training and runtime separation

Training is an explicit local task. It reads only data/training.csv, fits a vocabulary and category weights, then saves models/category_model.joblib. At runtime the application loads this trusted artifact and predicts. If the artifact is missing, local training runs automatically. Evaluation is a separate command that reads data/evaluation.csv and calls predict without updating the model.

### Persistence boundary

Natural-language text never becomes SQL code. Database writes use parameterised statements. Monetary totals rely on integer paise in SQLite. A bill payment performs its reminder update and linked expense insert in a single transaction, so a partial payment-state update cannot remain after a failed operation.

## Rule based NLP extraction

### Intent identification

Case-insensitive, word-boundary rules recognise supported reminder, income, and expense terms. Reminder language takes priority over payment words because “remind me to pay” describes a future obligation. Mixed income and expense signals leave intent blank. Supported negation patterns, such as “did not” and “haven’t”, also leave intent blank for review. A few common spelling variants are recognised explicitly. These are finite rules rather than general language understanding.

### Amount extraction

Currency-marked candidates accept ₹, Rs, Rs., and INR. Valid numbers use conventional comma thousands grouping and at most two decimal places. Currency candidates take precedence over unmarked quantities, so “₹300 for 2 pizzas” extracts 300. When currency markers are absent, recognised dates are removed before the numeric search. Several monetary candidates leave the amount blank rather than silently selecting one.

The save validator requires a positive finite amount no greater than INR 1,000,000,000. Zero, negatives, missing values, malformed grouping, and excessive decimal precision fail validation. The preview uses zero for an oversized extracted amount so it cannot be saved without correction. Amounts written as words and lakh-style comma grouping remain unsupported.

### Date extraction

A phrase recogniser identifies today, yesterday, tomorrow, the day before yesterday, the day after tomorrow, next weekdays, English day-month dates, ISO dates, and DD/MM/YYYY dates. dateparser resolves the detected phrase using an explicit relative base. ISO strings use YMD ordering, numeric slash dates use DMY, and yearless reminder dates prefer the future. The “next Friday” rule means the next occurrence, seven days later when today is Friday. [3]

Transactions without a date default to today. Reminders require a recognised or manually selected date. Invalid explicit dates and multiple date candidates remain blank. Past reminder dates are allowed because the user may need to record an already overdue bill.

### Review and correction

Warnings explain uncertainty. The reviewed fields determine the saved record, so the user can correct an unknown intent or ambiguous amount without retyping the sentence.

## Machine learning pipeline

### Preprocessing and feature extraction

The category classifier uses scikit-learn’s TfidfVectorizer. It lowercases text, applies the standard word tokenizer, removes English stop words, and builds unigram and bigram features. Vocabulary and inverse document frequency values come entirely from the included training descriptions. The implementation enables sublinear term frequency. These transformations convert variable-length descriptions into sparse numeric vectors. [1]

For term t in description d, the sublinear term-frequency weight is 1 + log(count(t,d)) when the count is positive. With smoothing, inverse document frequency is log((1 + N)/(1 + df(t))) + 1. The vectorizer multiplies these weights and applies its default L2 vector normalisation. N is the number of fitted descriptions, and df is the number containing the term.

### Classifier

Logistic Regression learns one set of category weights from labelled vectors and chooses the class with the largest predicted probability. The project uses C = 4, max_iter = 1000, and random_state = 42. A scikit-learn Pipeline keeps feature extraction and classification together during fitting, cross-validation, persistence, and prediction. The model is a supervised linear classifier, not a generative language model. [2]

### Categories and label policy

The ten supported labels are Food, Transport, Shopping, Utilities, Rent, Healthcare, Education, Entertainment, Salary, and Other. Because the requested taxonomy has one income category, Salary also covers wages, stipends, freelance earnings, and related earned income in this teaching dataset. Charity, courier, service fees, and uncategorised expenses use Other.

### Unknown text and persistence

When the cleaned description has no recognised TF-IDF features, the NLP layer suggests Other. When some familiar words exist, the classifier may still make an incorrect prediction. The preview therefore remains essential. joblib stores both the vectorizer and classifier in one trusted local artifact. Retrain after changing the CSV or upgrading incompatible library versions. The application does not learn automatically from edits to saved transactions.

### Why this approach

The model is small, CPU-based, explainable, and reproducible from the included CSV. Its tradeoff is limited understanding of context, paraphrases, spelling errors, and descriptions containing competing category terms.

## Dataset and evaluation protocol

| Dataset | Rows | Per category | Purpose |
| --- | --- | --- | --- |
| Original baseline corpus | 150 | 15 | Earlier fitted model retained for comparison |
| Expanded training.csv | 400 | 40 | Fit vocabulary and category weights |
| Separate evaluation.csv | 100 | 10 | Measure frozen model on held-out descriptions |

The expanded training file retains the original 150 descriptions and adds 250 varied examples. New examples include everyday student purchases, vendor names, service wording, abbreviations, longer phrases, and selected common misspellings. All rows contain a description and one category. These are synthetic teaching examples, not collected bank statements or private financial records.

### Separate evaluation set

The 100 evaluation descriptions were authored separately and fixed before measuring the updated model. They do not contain exact normalised duplicates of training descriptions. The audit lowercases text, normalises punctuation and spacing, rejects duplicate descriptions, checks all labels, and rejects cross-file overlap. Shared domain vocabulary remains expected, and semantic similarity between synthetic examples can still make the task easier than real user input.

### Experimental procedure

- Preserve the earlier 150-row model before expanding the training file.
- Keep evaluation.csv outside the fitting routine.
- Run three-fold stratified cross-validation on training.csv with shuffle and seed 42.
- Fit the final Pipeline on all 400 training rows and save it.
- Evaluate the final and earlier models on the same fixed 100-row evaluation set.
- Save predictions, per-class metrics, confusion matrix, and dataset/model hashes.

### Measurement boundaries

No evaluation examples were added to training, and no hyperparameters were selected based on evaluation errors. Category evaluation measures the frozen classifier on description text. It does not measure the accuracy of every field in unrestricted sentences. NLP field behaviour is checked separately through automated acceptance and edge-case tests.

### Future evaluation

If this evaluation set later guides feature engineering or dataset additions, treat it as a development set and reserve a new untouched test set. Real-world generalisation should be assessed using independently collected, consented descriptions with human-reviewed labels.

## Database design and consistency

### Entries table

| Field | Meaning |
| --- | --- |
| id | Auto-increment integer identifier |
| intent | Expense, Income, or Reminder |
| amount_paise | Positive integer amount in hundredths of INR |
| date | Transaction or due date as ISO text |
| description and category | Reviewed description and supported category label |
| paid | 0 for unpaid, 1 for paid reminders |
| source_reminder_id | Unique link from an actual expense to its reminder |
| created_at | SQLite creation timestamp |

### Budgets table

Each row contains a month key in YYYY-MM format and a non-negative integer amount in paise. Saving a budget for an existing month replaces that month’s value. A zero budget disables the overspending warning. The selected reporting month does not hide records from the complete history or export.

### Money and monthly summaries

The application converts validated amounts to integer paise before insertion. It sums these integers, then divides by 100 for display. This avoids floating-point accumulation errors in financial totals. Monthly income and expenses use the stored transaction date. Reminders are excluded until they produce an actual expense.

### Paid reminder transaction

Marking a reminder paid begins an immediate SQLite transaction, checks that the record is an unpaid reminder, inserts one linked Expense dated today, and updates the paid flag. A repeated call returns without creating another expense. The unique source_reminder_id supplies an additional consistency constraint. Python’s sqlite3 connection context manages commit or rollback. [5]

### Editing and deletion rules

Paid reminders and their linked expenses are locked for editing. Deleting a linked expense reopens the reminder. Deleting a paid reminder keeps the actual expense and removes its source link. These rules protect consistency while preserving a way to correct a mistaken payment record. A manually duplicated bill is outside automatic deduplication and should be reviewed by the user.

### Storage and backups

The local file data/expenses.db is created on startup and survives application restarts. For a simple backup, stop the application and copy this file. Tests use temporary databases and do not change the delivered history.

## Interface and reminder workflow

### Input and editable preview

The Add entry tab provides a text area and Extract details button. Extraction displays warnings and editable intent, amount, date, description, and category fields. The Save transaction button validates the reviewed fields before calling the database. Invalid fields remain available for correction. The form does not save automatically when the sentence changes.

### History and editing

History lists all records or filters them by intent. Selecting a record opens an edit form unless its payment link locks it. A confirmation checkbox enables deletion. Widget callbacks perform writes before the next display pass, keeping summaries and form state consistent after saving or editing.

### Reminder states

| State | Condition | Available behaviour |
| --- | --- | --- |
| Overdue | Unpaid and due before today | Display warning and Mark as paid |
| Due today | Unpaid and due today | Display warning and Mark as paid |
| Upcoming | Unpaid and due after today | List future bill and Mark as paid |
| Paid | Payment recorded locally | Show status and linked actual expense |

The reminder screen sorts unpaid bills by due date. Refresh recalculates date-dependent status. Alerts appear while the application is running and open. There is no background scheduler, email integration, or mobile notification service. The application cannot verify whether an actual external bill payment occurred.

### Budgets and analysis

The sidebar selects a month and persists its budget. Summary metrics show income, expenses, balance, and remaining budget. An overspending message appears when recorded expenses exceed a positive budget. The Insights tab provides category spending and income-versus-expense charts. Unpaid reminders do not inflate spending totals.

### Export

The CSV download includes all history, not just the reporting month. It contains record identity, intent, amount, date, description, category, paid state, and source reminder link. Formula-like description values are escaped to reduce accidental spreadsheet formula execution when the CSV is opened.

## Testing and acceptance criteria

The final automated run passed 85 pytest cases. Tests use fixed relative dates for NLP assertions and temporary SQLite files for write workflows. Streamlit AppTest executes actual application forms, including button clicks and field edits, without relying only on helper-function checks. [4]

| Test area | Checks |
| --- | --- |
| Required acceptance | Four requested sentences assert intent, amount, category, and date |
| Amounts | Currency prefixes, commas, decimals, zeros, negatives, malformed and multiple values |
| Intent | Word boundaries, upper case, supported typo, mixed signals, negation |
| Dates | Relative dates, ISO and DMY, next weekday, year change, leap years, invalid and multiple dates |
| Classification | Local training, missing artifact, unseen vocabulary, ten categories |
| Data separation | Balanced counts, duplicate/overlap rejection, complete confusion matrix |
| SQLite | CRUD, restart persistence, exact totals, budget updates, payment idempotency |
| Interface | Save/edit/pay, invalid-field correction, missing dates, budgets, deletion, ambiguous amounts |

### Required examples

| Sentence summary | Expected result |
| --- | --- |
| Spent INR 300 on pizza today | Expense, 300, Food, today |
| Paid 500 for bus travel yesterday | Expense, 500, Transport, yesterday |
| Received Rs 20000 salary today | Income, 20000, Salary, today |
| Remind me to pay electricity bill of INR 1200 tomorrow | Reminder, 1200, Utilities, tomorrow |

### Execution evidence

The final test output was “85 passed in 2.98s”. The real Streamlit server started successfully. Browser inspection verified the editable preview and bill/analysis screens using an isolated demo database with synthetic records. Automated tests and interface smoke checks assess functional correctness, while the separate category evaluation measures predictive behaviour.

### Uncovered conditions

The suite does not prove unrestricted English understanding, public-service security, browser compatibility across every device, heavy concurrent usage, or successful external payment. Those behaviours are outside the project scope.

## Experimental results and error analysis

| Measure | Result | Dataset |
| --- | --- | --- |
| Original model accuracy | 88.0% | Same separate 100-row evaluation set |
| Expanded model accuracy | 98.0% | Separate 100-row evaluation set |
| Expanded model macro F1 | 0.980 | Separate 100-row evaluation set |
| Expanded training cross-validation | 91.7% | Three stratified folds on 400 training rows |
| Automated functional tests | 85 passed | NLP, data, database, and Streamlit tests |

The same-set comparison shows ten additional correct category predictions after expanding the training corpus. Cross-validation and separate evaluation use different partitions and should not be directly compared as equivalent measurements. The high held-out score is plausible for repeated domain vocabulary in a small synthetic corpus, but it is not a guarantee for new users.

### Per category evaluation

| Category | Precision | Recall | F1 | Support |
| --- | --- | --- | --- | --- |
| Food | 0.91 | 1.00 | 0.95 | 10 |
| Transport | 1.00 | 1.00 | 1.00 | 10 |
| Shopping | 1.00 | 1.00 | 1.00 | 10 |
| Utilities | 1.00 | 1.00 | 1.00 | 10 |
| Rent | 0.91 | 1.00 | 0.95 | 10 |
| Healthcare | 1.00 | 1.00 | 1.00 | 10 |
| Education | 1.00 | 0.90 | 0.95 | 10 |
| Entertainment | 1.00 | 1.00 | 1.00 | 10 |
| Salary | 1.00 | 1.00 | 1.00 | 10 |
| Other | 1.00 | 0.90 | 0.95 | 10 |

### Observed errors

“photocopy of study material for exams” has the Education label but the model predicted Food. “payment for duplicate house keys” has the Other label but the model predicted Rent. These cases show vocabulary and context limitations. The evaluation examples were not moved into training to hide these errors. The editable category field provides a practical correction path.

### Saved evidence

evaluation/metrics.json stores aggregate metrics, category counts, and SHA-256 hashes. predictions.csv preserves every expected and predicted category. classification_report.csv and confusion_matrix.csv provide detailed analysis. The earlier model is retained as models/baseline_150.joblib for repeatable comparison.

## Application screenshots

The following screenshots show the actual local application with synthetic demonstration data. The screenshots are dated 12 October 2026 and do not show the user’s personal financial records.

![Figure 1 Editable preview after extracting the pizza expense](docs/assets/extraction.jpg)

![Figure 2 Upcoming and overdue bill reminders in the demonstration database](docs/assets/reminders.jpg)

## Installation limitations and conclusion

### Installation and operation

From the project folder, create an environment and install the supplied requirements. Train locally, evaluate the saved model, run the tests, and start Streamlit. The README contains the absolute workspace path and Windows activation alternative.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train_model.py
python evaluate_model.py --baseline models/baseline_150.joblib
python -m pytest -q
python -m streamlit run app.py
```

Open http://127.0.0.1:8501. Stop the server with Ctrl+C. If the model is incompatible with a changed scikit-learn version, rerun the training command. Do not load untrusted joblib files. A fresh clone creates its own SQLite file on startup.

### Limitations

The system supports selected English phrases, one entry per sentence, INR amounts with conventional comma grouping, and a finite set of date expressions. Spelling support is limited to observed training vocabulary and a few intent variants. Synthetic data cannot establish real-world accuracy. The application has no authentication, encryption, bank integration, recurring bills, or background notifications. The Salary category covers several earned-income types because the specified taxonomy provides no separate freelance or stipend class.

### Future improvements

Collect consented descriptions from varied users, review labels independently, and reserve a new test set before using the current errors for development. Potential extensions include richer local language rules, Indian lakh-style numbers, recurring reminders, receipt OCR, account separation, and encrypted backups. Each extension should add focused tests and explicit user-facing behaviour.

### Conclusion

The delivered system demonstrates an offline combination of rules and supervised text classification for personal finance entry. Editable previews, validation, durable records, and atomic reminder payments make the prototype usable. The evaluation and tests provide reproducible evidence of its current behaviour while making its predictive and operational limits clear.

## References and reproducibility

The implementation files and saved evaluation outputs are the primary evidence for project-specific behaviour and numerical results. The official documentation below supports the underlying library concepts. Accessed 12 October 2026. Documentation websites may describe versions newer than the tested environment, so use requirements-lock.txt to identify the versions used for this delivery.

[1] scikit-learn. Text feature extraction and TF-IDF. https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction

[2] scikit-learn. Logistic Regression. https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression

[3] dateparser. Human readable date parsing. https://dateparser.readthedocs.io/en/latest/

[4] Streamlit. App testing and AppTest. https://docs.streamlit.io/develop/api-reference/app-testing

[5] Python documentation. sqlite3 database interface. https://docs.python.org/3/library/sqlite3.html

### Local evidence files

- data/training.csv and data/evaluation.csv contain the active fitting and evaluation corpora.
- data/baseline_training_150.csv records the earlier corpus retained for provenance.
- train_model.py and evaluate_model.py reproduce fitting and evaluation.
- evaluation/metrics.json identifies dataset/model hashes and measured metrics.
- evaluation/predictions.csv shows all 100 evaluation outcomes.
- tests and VERIFICATION.md record functional verification.
- README.md documents installation, operation, and behaviour.

### Recorded dataset hashes

Training SHA-256: 0738cff7d5769b5ae4ab70c7f4f806b73784eb49b3dd88e26d348b055713b97b

Evaluation SHA-256: cb94404a0e6de32480b4060ec6455d3d94eaa76089162dd19fca3c931fc5e9ab

### Presentation preparation

The accompanying PowerPoint contains speaker notes and the same measured results. VIVA_AND_DEMO.md provides questions and a demonstration script. Replace the student and institution placeholders before submission and check the college’s required format.
