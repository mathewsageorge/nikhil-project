## Slide 1

Introduce the project and your name. Explain that the application runs locally with a small supervised classifier and no external AI API or pretrained language model. Replace all student, college, and guide placeholders before presenting.

## Slide 2

Explain the problem with recording daily spending in scattered notes. The goal is to suggest fields from one sentence, preserve user review, and keep bills visible. The app records information but never makes an actual payment.

## Slide 3

Demonstrate the acceptance example. Today resolves using the local computer date. The description cleanup is heuristic and can retain connecting words. The user must review every field. Source: nlp.py and the required acceptance tests.

## Slide 4

The architecture separates interface, extraction, fitting, evaluation, and persistence. Training reads only training.csv. The running app loads the saved joblib Pipeline. Evaluation calls predict only. Source: application modules.

## Slide 5

Intent is rule-based. Reminder terms take precedence over payment words. Mixed or supported negated intents stay blank. Amount extraction supports currency prefixes and conventional comma grouping. Multiple amounts/dates require manual correction. dateparser resolves recognised dates. Sources: nlp.py and https://dateparser.readthedocs.io/en/latest/

## Slide 6

Explain that TF-IDF produces sparse numeric features, and Logistic Regression learns category weights. Both fit only on the labelled local CSV. The Pipeline is not an LLM. Unseen zero-feature text falls back to Other in nlp.py. Sources: train_model.py; https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction; https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression

## Slide 7

The 400-row training file includes the original 150 plus 250 added descriptions. Each category has 40 training and 10 evaluation examples. The original baseline corpus is retained for provenance, not used as a second evaluation set. Both active corpora are synthetic, with no exact normalised cross-file duplicates. Source: data CSV files and evaluate_model.audit_datasets.

## Slide 8

The evaluation set was fixed before measuring the updated model. We did not tune hyperparameters or move evaluation errors into training. CV uses only training.csv and fits the complete Pipeline inside each fold. If the holdout later guides changes, reserve a new test set. Source: evaluate_model.py and evaluation/metrics.json.

## Slide 9

The earlier 150-row model and the expanded model were evaluated on the same fixed 100-row synthetic evaluation set. They scored 88 and 98 correct respectively. Macro F1 is 0.980 for the expanded model. Training cross-validation is 91.7% on a different partition and is not directly equivalent to the holdout score. These results do not establish real-world accuracy. Source: evaluation/metrics.json.

## Slide 10

There were two category errors. They remain in the evaluation evidence. Familiar words can dominate a sparse linear model, so the preview lets the user correct the category. No evaluation examples were added to training to hide these errors. Source: evaluation/predictions.csv.

## Slide 11

Store money as integer paise. Unpaid reminders do not count as spending. Marking paid inserts one linked expense and updates the reminder atomically. Repeated calls cannot duplicate the linked expense. Deleting that expense reopens the reminder. Deleting a paid reminder preserves the actual expense. Source: database.py and database tests.

## Slide 12

Actual screenshot from an isolated demonstration copy of the application using synthetic data, captured on 12 October 2026. The preview shows Expense, 300, the local date, on pizza, and Food. Editing changes what will be saved. Source: docs/assets/extraction.jpg.

## Slide 13

Actual screenshot from the synthetic demonstration database. One internet bill is overdue and one electricity bill is upcoming. Mark as paid records a local expense. The app must be running and open for alerts. It does not send email/mobile notifications or make real payments. Source: docs/assets/reminders.jpg.

## Slide 14

Actual screenshot from synthetic demo records. The reporting month controls totals and charts. Unpaid reminders stay out of expenses. The CSV export includes all history. Budget overspending appears when actual monthly expenses exceed a positive budget. Source: docs/assets/insights.jpg and app.py.

## Slide 15

Final run: 85 passed in 2.98 seconds. Required acceptance cases assert intent, amount, category, and date. Edge tests cover multiple values, negation, mixed intents, date boundaries, and invalid numbers. Database tests use temporary SQLite files. AppTest exercises real Streamlit forms. Source: tests directory and VERIFICATION.md. AppTest documentation: https://docs.streamlit.io/develop/api-reference/app-testing

## Slide 16

The app recognises selected English expressions and one entry at a time. Synthetic holdout accuracy is optimistic. Common spelling examples do not imply general spell correction. Future work should collect independently labelled descriptions and reserve a new test set before using current errors for development. No background notifications, banking, or public-service authentication exist. Source: PROJECT_REPORT.md.

## Slide 17

Plan a 7 to 10 minute presentation followed by a 3 minute live demonstration. Enter the four acceptance sentences, correct a preview, show a missing-date rejection, mark a bill paid, set a budget, display charts, and export CSV. Restart if time permits to demonstrate persistence. Explain that the reported 98% measures only category prediction on the synthetic holdout. Installation: README.md. Viva preparation: VIVA_AND_DEMO.md.
