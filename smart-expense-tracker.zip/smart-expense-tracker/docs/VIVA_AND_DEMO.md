# Viva preparation and demonstration guide

## Before submission

Replace the student, roll number, college, department, programme, guide, academic year, and submission-date placeholders in the report and slides. Use your college’s required certificate/declaration format. The supplied report describes the actual implementation and measured evidence, without invented signatures or approvals.

## Presentation plan

Allow about 8–10 minutes for the 17 slides and another 3–4 minutes for the live demo.

1. Explain the problem and the editable-entry workflow (slides 1–3).
2. Describe modules, rules, TF-IDF, and Logistic Regression (slides 4–6).
3. Explain the 400/100 dataset separation and evaluation method (slides 7–8).
4. Discuss results and the two observed errors (slides 9–10).
5. Show persistence, previews, reminders, and analysis (slides 11–14).
6. Distinguish tests from predictive accuracy and acknowledge limits (slides 15–17).

Speaker notes are embedded in the PowerPoint and also available in SPEAKER_NOTES.md.

## Live demonstration

Start the application with `python -m streamlit run app.py` from the project folder.

1. Enter **Spent ₹300 on pizza today**. Click Extract details. Explain each field, correct the description if desired, and save.
2. Enter **Paid 500 for bus travel yesterday**. Show Transport and yesterday’s date, then save.
3. Enter **Received Rs 20000 salary today**. Show Income and Salary, then save.
4. Enter **Remind me to pay electricity bill of ₹1200 tomorrow**. Save the reminder and show it in Bill reminders.
5. Enter **Reminder ₹799 internet bill**. Show that the missing date prevents saving. Select a valid due date and save.
6. Enter **Spent ₹100 on pizza and ₹50 on taxi today**. Explain that the app leaves the amount blank rather than guessing. Split it into two entries or deliberately correct the reviewed fields.
7. Mark one reminder paid. Show that one Expense appears and the reminder becomes Paid. This records a local payment status only and does not pay the real bill.
8. Set a small monthly budget, show the overspending warning, inspect charts, and export CSV.
9. If time permits, stop and restart the server. Show that SQLite keeps the records.

Use made-up demo records rather than real personal information during a presentation. The screenshots in the report/slides came from an isolated synthetic demo copy.

## Questions and short answers

### 1 What is the project’s main contribution

It combines lightweight sentence extraction with an editable review stage, durable expense history, local bill status, and monthly analysis. It provides a complete offline prototype rather than an autonomous financial assistant.

### 2 Why use rules and a classifier together

Amounts and supported intent/date expressions are easy to explain with rules. Category wording varies more, so a small supervised classifier learns useful word associations from labelled examples.

### 3 What does TF-IDF mean

Term Frequency Inverse Document Frequency. It weights terms using their frequency in a description and how common they are across the fitted corpus, then represents each description as a numeric vector.

### 4 What preprocessing occurs

Description cleanup removes recognised dates, amounts, and common action phrases. TfidfVectorizer lowercases, tokenises, removes English stop words, and constructs unigram/bigram features.

### 5 Why Logistic Regression

It is a compact supervised linear classifier that works with sparse TF-IDF features, trains locally on a CPU, and is straightforward to explain. The project uses C=4 and max_iter=1000.

### 6 Is this an LLM or pretrained model

No. The vocabulary and weights are learned from the included CSV. The application uses no external AI API, pretrained language model, transformer, GPU, or API key.

### 7 What is the dataset size

400 active training descriptions, 40 per category, and 100 separate evaluation descriptions, ten per category. The earlier 150-row corpus and model are retained for comparison.

### 8 How is evaluation separate from training

The fitting script reads only training.csv. The evaluation script audits the split and calls predict on evaluation.csv without updating vocabulary or weights. No exact normalised descriptions overlap.

### 9 What are the measured results

The expanded model correctly predicted 98 of 100 separate evaluation descriptions, with macro F1 of 0.980. The original model correctly predicted 88 on the same set. Three-fold cross-validation on the expanded training set averaged 91.7% accuracy. All 85 functional tests passed.

### 10 Does 98 percent mean the app understands 98 percent of sentences

No. It measures category classification on 100 synthetic descriptions. It does not measure every extraction field or unrestricted real-user language. The sample is small and shares domain vocabulary with the training corpus.

### 11 Why can held-out accuracy exceed cross-validation accuracy

They use different examples and training sizes. Each CV fold trains on roughly two-thirds of the 400-row corpus, while the final model trains on all 400 rows. The synthetic evaluation set may also be easier. The scores are not directly interchangeable.

### 12 What is macro F1

For each category, F1 is the harmonic mean of precision and recall. Macro F1 averages the per-category F1 values equally, so every category has the same weight.

### 13 What errors remain

“photocopy of study material for exams” was labelled Education but predicted Food. “payment for duplicate house keys” was labelled Other but predicted Rent. The model can over-rely on familiar words and miss context.

### 14 Why not add those errors to training immediately

Doing so would contaminate this evaluation set and make its future score misleading. Use a development set for improvements and reserve a new untouched test set before measuring them.

### 15 Why is Salary used for freelance earnings and stipends

The specified ten-category taxonomy includes only one earned-income class. The project documents Salary as covering salary-like earned income. A future version could expand the taxonomy.

### 16 How are dates handled

The application recognises supported date phrases and uses dateparser with an explicit relative base and date ordering. Next weekdays have an explicit rule. Reminders require a valid date, while undated ordinary transactions default to today.

### 17 What happens with several amounts or dates

The parser leaves the relevant field blank and displays a warning. The user can split the sentence or provide a deliberate correction in the editable preview.

### 18 What happens with negated or mixed intents

Supported negations and mixed income/expense signals leave intent blank. The user must review the sentence and choose a correct intent before saving. This is a finite rule set, not unrestricted negation understanding.

### 19 How does it handle unseen words and spelling mistakes

Some spelling variations exist in training, and a few intent typos have explicit rules. Fully unrecognised TF-IDF vocabulary suggests Other. There is no general spell checker, and familiar but misleading words can still produce errors.

### 20 Why use SQLite

It is embedded in Python, requires no database server, and persists records locally. Parameterised queries keep user input separate from SQL statements.

### 21 Why store money as paise

Integer paise avoid floating-point accumulation errors. A value like INR 400.25 is stored as 40025 and converted only for display.

### 22 How do repeated payment clicks avoid duplicate expenses

A transaction checks the paid flag, inserts one linked expense, and marks the reminder paid atomically. A unique source_reminder_id adds a database consistency constraint. A second call cannot insert another linked expense.

### 23 Are reminders actual spending before payment

No. Monthly totals count Income and Expense records only. An unpaid Reminder stays out of spending until Mark as paid creates an Expense dated today.

### 24 Can a paid reminder be edited

Paid reminders and linked expenses are locked for editing. Delete the linked expense to reopen its reminder. Deleting a paid reminder preserves the real expense and unlinks it.

### 25 Can the app send alerts while closed

No. Alerts appear in the running, open application. Refresh updates date status. Background email or mobile notifications are not implemented.

### 26 Does editing a category retrain the model

No. Edits affect saved records only. To improve the classifier, add reviewed examples to training.csv and explicitly retrain. Never copy evaluation rows into training while still treating them as held-out tests.

### 27 What is the difference between automated tests and model evaluation

Automated tests verify specified behaviour, such as rejecting invalid amounts or avoiding duplicate payments. Model evaluation measures how well predictions match labels on separate examples. A passing test suite does not prove universal language accuracy.

### 28 What should be improved next

Collect independently labelled user descriptions with consent, reserve a fresh test set, and add focused support for more local date/amount expressions. Recurring reminders and encrypted backups are useful extensions.

## Commands to explain during the viva

```bash
python train_model.py
python evaluate_model.py --baseline models/baseline_150.joblib
python -m pytest -q
python -m streamlit run app.py
```

`train_model.py` refits only from training.csv. `evaluate_model.py` measures the frozen saved model. `pytest` checks behaviour. `streamlit run` serves the interactive application.
