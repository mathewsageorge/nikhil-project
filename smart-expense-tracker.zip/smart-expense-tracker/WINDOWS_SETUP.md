# Run the project on a friend's Windows laptop

## Prepare the Windows laptop

Smart Expense Tracker and Bill Reminder Using Natural Language Processing. Follow this guide on a Windows 10/11, 64-bit laptop. The application runs on that laptop; hosting is not required.

### 1. Copy and extract the project

Send your friend smart-expense-tracker.zip. Right-click the ZIP, choose Extract All, and open the extracted smart-expense-tracker folder. Keep the folder on the laptop, outside the ZIP and outside Program Files. A normal local folder is preferable to a cloud-synced folder.

Check that app.py, requirements.txt, train_model.py, data, models, SETUP_WINDOWS.bat, and START_WINDOWS.bat are visible together. Do not copy the Mac .venv or work folder. Python environments must be created again on the Windows laptop.

### 2. Install Python 3.12

Open https://www.python.org/downloads/ and install the official Python install manager for Windows. After installation, open a new Command Prompt: press the Windows key, type cmd, and press Enter.

Run these commands one at a time:

```bat
pymanager install 3.12
py -3.12 --version
```

The second command must report Python 3.12.x. If Python 3.12 is already installed and this check works, skip the install command. Use Python 3.12 for this guide instead of selecting the newest Python release automatically; the project dependencies have version limits.

### 3. Open Command Prompt inside the project

In File Explorer, open the folder containing app.py. Click the address bar, type cmd, and press Enter. A Command Prompt opens in that exact folder. This avoids guessing your friend's username or folder path.

```bat
dir app.py
dir requirements.txt
```

Both files must be listed. If not, open the inner smart-expense-tracker folder and repeat this step. The next page contains the first-time setup commands.

## Install once, then start the app

### 4. First-time setup

Keep internet connected while installing Python and packages. From the project Command Prompt, run each line below. Continue only when the previous command completes successfully.

```bat
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe train_model.py
.\.venv\Scripts\python.exe -m pytest -q
```

Training recreates the included classifier using the packages installed on this laptop. This avoids saved-model version problems after moving between computers. Training uses only data/training.csv; it does not download a language model.

The supplied application currently has 92 automated tests. Confirm that the test run reports no failures before continuing. Do not copy the macOS requirements-lock.txt environment as your Windows installation recipe; use requirements.txt as shown.

### 5. Start the application

```bat
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

The start command is displayed on two lines only to fit this page. Type it as ONE line, with a space before --server.address. Alternatively, double-click START_WINDOWS.bat; it runs that exact command.

Open http://127.0.0.1:8501 in Chrome, Edge, or Firefox if the browser does not open automatically. If Streamlit asks for an email address in the terminal, leave it blank and press Enter. Keep the Command Prompt window open while using the app.

### 6. Start it again on another day

Double-click START_WINDOWS.bat inside the same project folder. No reinstall or retraining is needed for normal use. To stop, return to its terminal and press Ctrl+C. Closing only the browser tab does not stop the server.

### Optional: setup with fewer commands

After installing the Python install manager, you can double-click SETUP_WINDOWS.bat instead of entering step 4 manually. It creates the environment, installs packages, trains the classifier, and runs the tests. If it reports success, double-click START_WINDOWS.bat. Neither script deletes your financial records.

## Use the app and keep your records

### A quick first check

At the top of the app, enter: Spent Rs 300 on pizza today. Click Extract details. Review Expense, 300, Food, and today's date; then click Save transaction. Using Rs is useful if your friend's keyboard does not have the rupee symbol.

Check History to see the expense. Click Edit beside a transaction to open the editing pop-up. Save changes to update it. Deletion is inside the pop-up and requires confirmation.

Try: Remind me to pay electricity bill of Rs 1200 tomorrow. Review the due date and save. Bill reminders lists unpaid bills; choose Mark paid only after paying. This also records one expense. Paid reminders move into the Paid bills section.

Use Monthly plan to select the reporting month and save its budget. Insights & export shows charts and lets you download the history as CSV.

### Internet, alerts, and local access

After Python and packages are installed, the app, local model training, and tests can run offline. No AI service, API key, GPU, or downloaded pretrained model is needed. The browser and Python server both run on the same laptop.

Reminders appear inside the open app. Dashboard alerts refresh every minute while it is open. The application does not send background mobile or email notifications. Keep the Windows date and time correct.

### Where the records live

The database is created automatically at data/expenses.db inside the project. Closing or restarting the local app does not erase it. Each friend gets a separate database on their own laptop. Different copies of the project have different databases; there is no automatic syncing.

### Back up or transfer existing records

Stop the app with Ctrl+C before copying the database. Make a backup of data/expenses.db in a separate folder or USB drive. To transfer your own records deliberately, stop both copies of the app and copy that file into the friend's data folder. Back up their existing database before replacing it.

The downloadable ZIP intentionally excludes financial databases, so your friend starts with no personal transactions. A CSV export is useful for reading/sharing records, but the current app does not import CSV as a full database restore.

### Optional category evaluation

```bat
.\.venv\Scripts\python.exe evaluate_model.py
```

This evaluates the newly trained model on the separate evaluation CSV and refreshes the evaluation outputs. It does not train on those examples. Baseline comparison is optional and is not needed to run the app.

## Troubleshooting and checks

### Python or pymanager is not recognized

Install the official Python install manager, then close and reopen Command Prompt. If an older py launcher is installed, use pymanager install 3.12 to install the runtime, then check py -3.12 --version. If commands are still unavailable, follow the official Windows troubleshooting link below.

### requirements.txt or app.py cannot be found

You are in the wrong folder, or are viewing the ZIP without extracting it. Open the folder containing app.py in File Explorer, then type cmd in its address bar. Run dir app.py to confirm the folder.

### ModuleNotFoundError or streamlit is not recognized

Use the project environment's Python directly. Do not use a global streamlit command. Run:

```bat
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### PowerShell says script execution is disabled

This guide uses Command Prompt and calls python.exe directly, so activation is unnecessary. You do not need to change PowerShell execution policy. Open Command Prompt using the File Explorer address-bar method.

### Saved classifier is incompatible

```bat
.\.venv\Scripts\python.exe train_model.py
```

Then restart the app. This replaces only the category model, not your transaction database. If .venv came from another computer, keep your database backup and recreate the environment locally instead of reusing that copied environment.

### Port 8501 is already in use

Stop the old app terminal with Ctrl+C. Or run the normal start command with --server.port 8502 appended, and open http://127.0.0.1:8502. Do not start several servers against the same project unnecessarily.

### Package download or wheel installation fails

Confirm internet access and Python 3.12, 64-bit. Retry the pip upgrade and package installation steps. Copy the final error message if it still fails. Do not skip failed installation commands or use the latest Python major/minor version without checking dependency compatibility.

### Verification and sources

The application passed 92 tests on the development Mac. The Windows commands and batch scripts were reviewed, but have not been executed on a Windows machine in this workspace. Step 4 provides the actual verification on your friend's laptop.

Official Python download: https://www.python.org/downloads/
Windows install manager and command documentation: https://docs.python.org/3/using/windows.html
Virtual environments: https://docs.python.org/3/library/venv.html
Instructions checked: 12 October 2026.
