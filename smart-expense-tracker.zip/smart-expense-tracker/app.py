"""Run with: python -m streamlit run app.py"""
from datetime import date
from html import escape
import pandas as pd
import plotly.express as px
import streamlit as st
import database as db
from nlp import parse_entry, validate_entry
from train_model import CATEGORIES

st.set_page_config(page_title='Smart Expense Tracker', page_icon='💸', layout='wide')
db.init_db()
st.markdown("""<style>
:root {--ink:#172c38; --muted:#607381; --line:#e2e9ed;}
.stApp {background:#f5f7fa; color:var(--ink);}
.block-container {max-width:1260px; padding:2rem 2rem 4rem;}
[data-testid="stDeployButton"], .stDeployButton {display:none !important;}
[data-testid="stHeader"] {background:transparent;}
h1,h2,h3 {letter-spacing:-.035em; color:var(--ink);}
h1 {font-size:2.25rem !important;}
[data-testid="stSidebar"] {background:#fff; border-right:1px solid var(--line);}
[data-testid="stMetric"] {background:#fff; border:1px solid var(--line); padding:20px 18px;
 border-radius:16px; box-shadow:0 3px 12px #172c3804; height:100%;}
[data-testid="stColumn"]:nth-child(1) [data-testid="stMetric"] {border-top:3px solid #16805d;}
[data-testid="stColumn"]:nth-child(1) [data-testid="stMetricValue"] {color:#16805d;}
[data-testid="stColumn"]:nth-child(2) [data-testid="stMetric"] {border-top:3px solid #c45749;}
[data-testid="stColumn"]:nth-child(2) [data-testid="stMetricValue"] {color:#b4493e;}
[data-testid="stColumn"]:nth-child(3) [data-testid="stMetric"] {border-top:3px solid #487fa3;}
[data-testid="stMetricValue"] > div {white-space:normal; overflow-wrap:anywhere;}
[data-testid="stMetricLabel"] {color:var(--muted); font-size:.85rem;}
[data-testid="stMetricValue"] {font-size:clamp(1.1rem,1.65vw,1.6rem); font-weight:700;}
[data-testid="stTabs"] {margin-top:1.5rem;}
[data-baseweb="tab-list"] {gap:12px; border-bottom:1px solid var(--line);}
[data-baseweb="tab"] {padding:12px 8px; font-weight:600;}
[data-testid="stForm"] {background:#fff; border:1px solid var(--line); border-radius:16px;}
.reminder-card {background:#fff; border:1px solid var(--line); border-left:4px solid #4884c3;
 border-radius:12px; padding:15px 18px; margin-bottom:10px;}
.reminder-card.overdue {border-left-color:#d34242; background:#fff8f8;}
.reminder-card.urgent {border-left-color:#d68b16; background:#fffcf5;}
.reminder-title {font-size:1rem; font-weight:650; margin-bottom:5px; overflow-wrap:anywhere;}
.reminder-meta {color:var(--muted); font-size:.86rem; line-height:1.7;}
.status {font-weight:650; color:#356d9f;}
.overdue .status {color:#b52d2d;} .urgent .status {color:#a26405;}
.finance-item {padding:4px 0;}
.finance-main {display:flex; justify-content:space-between; gap:20px; align-items:baseline;}
.finance-name {font-size:1rem; font-weight:650; overflow-wrap:anywhere;}
.finance-amount {font-size:1rem; font-weight:650; white-space:nowrap;}
.finance-meta {color:var(--muted); font-size:.85rem; margin-top:5px; line-height:1.6;}
.finance-amount.income {color:#16805d;}
.finance-status {display:inline-block; padding:2px 8px; border-radius:6px; background:#eaf1f7; color:#356d9f; font-weight:600;}
.finance-status.overdue {background:#fff0ee; color:#ad3830;}
.finance-status.urgent {background:#fff4dc; color:#9b670c;}
.finance-status.paid {background:#eaf6ef; color:#16805d;}
[class*="st-key-finance-row-"] {background:#fff; border-bottom:1px solid var(--line); padding:14px 18px;}
@media(max-width:850px) {
 [class*="st-key-finance-row-"] [data-testid="stHorizontalBlock"] {flex-wrap:nowrap;}
 [class*="st-key-finance-row-"] [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {min-width:0;}
 [class*="st-key-finance-row-"] [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child {flex:1 1 0;}
 [class*="st-key-finance-row-"] [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {flex:0 0 100px;}
 .finance-main {flex-direction:column; gap:3px;}
}
.budget-panel {background:#fff; border:1px solid var(--line); border-radius:16px; padding:22px; margin-top:22px;}
.budget-top {display:flex; justify-content:space-between; gap:12px; align-items:start; flex-wrap:wrap;}
.budget-title {font-size:1.1rem; font-weight:700; margin:0 0 8px;}
.budget-copy {color:var(--muted); font-size:.9rem;}
.budget-remaining {font-size:1.15rem; font-weight:700; text-align:right;}
.budget-track {height:10px; background:#edf1f4; border-radius:10px; margin:20px 0 12px; overflow:hidden;}
.budget-fill {height:100%; border-radius:10px;}
.budget-status {font-size:.9rem; font-weight:600;}
@media(max-width:850px) {
 .block-container {padding:1.25rem 1rem 3rem;}
 [data-testid="stHorizontalBlock"] {flex-wrap:wrap; gap:12px;}
 [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {min-width:180px; flex:1 1 180px;}
 [data-testid="stMetricValue"] {font-size:1.5rem;}
 [data-baseweb="tab-list"] {gap:4px;}
 [data-baseweb="tab"] {font-size:.85rem;}
}
</style>""", unsafe_allow_html=True)
st.title('Your money, at a glance')
st.caption('Track spending, plan your budget, and stay ahead of bills.')
if 'notice' in st.session_state:
    st.success(st.session_state.pop('notice'))

def save_budget(month):
    db.set_budget(month, st.session_state[f'budget_{month}'])
    st.session_state.notice = f'Budget saved for {month}.'


def pay_reminder(entry_id):
    db.mark_paid(entry_id)
    st.session_state.notice = 'Bill marked paid and expense recorded.'


frame = db.list_entries()
selected_month = st.session_state.get('month', date.today())
month = selected_month.strftime('%Y-%m')
budget = db.get_budget(month)


def rupees(value):
    return f'₹{value:,.2f} INR'


@st.fragment(run_every='60s')
def dashboard(selected_month_key):
    """Refresh date-sensitive alerts while open, using the latest stored records."""
    current_frame = db.list_entries()
    current_budget = db.get_budget(selected_month_key)
    current_income, current_expense = db.monthly_summary(current_frame, selected_month_key)
    pending = current_frame[(current_frame.intent == 'Reminder') & (current_frame.paid == 0)].copy()
    pending = pending.sort_values('date')
    ratio = current_expense / current_budget if current_budget else 0
    budget_alert = current_budget > 0 and ratio >= .8
    if not pending.empty or budget_alert:
        st.subheader('Reminders')
        st.caption('Your upcoming payments and items that need attention.')
        for row in pending.itertuples():
            due = date.fromisoformat(row.date)
            days = (due - date.today()).days
            status = 'Overdue' if days < 0 else 'Due today' if days == 0 else 'Due soon' if days <= 3 else 'Upcoming'
            tone = 'overdue' if days < 0 else 'urgent' if days <= 3 else ''
            st.markdown(f'<div class="reminder-card {tone}"><div class="reminder-title">{escape(row.description)}</div>'
                        f'<div class="reminder-meta">{rupees(row.amount)} &nbsp; · &nbsp; Due {due:%d %b %Y}'
                        f' &nbsp; · &nbsp; <span class="status">{status}</span></div></div>', unsafe_allow_html=True)
        if budget_alert:
            if ratio > 1:
                st.warning(f'Overspending · {selected_month_key}: budget exceeded by {rupees(current_expense-current_budget)}.')
            else:
                st.warning(f'Budget alert · {selected_month_key}: {ratio:.0%} used. {rupees(current_budget-current_expense)} remaining.')
        st.caption('Manage payments in the Bill reminders tab below.')
    st.subheader('Monthly overview')
    st.caption(f'{date.fromisoformat(selected_month_key + "-01"):%B %Y} · Income and expenses for your selected month')
    labels = ['↗ Total Income', '↘ Total Expenses', '◈ Current Balance', '▣ Monthly Budget', '◷ Budget Remaining']
    values = [current_income, current_expense, current_income-current_expense, current_budget, current_budget-current_expense]
    for col, label, value in zip(st.columns(5), labels, values):
        col.metric(label, rupees(value) if current_budget or 'Budget' not in label else 'Not set')
    if current_budget:
        color = '#c13d3d' if ratio > 1 else '#bd790c' if ratio >= .8 else '#16805d'
        status = 'Budget exceeded' if ratio > 1 else 'Approaching your limit' if ratio >= .8 else 'Budget under control'
        remaining_label = 'Over budget' if ratio > 1 else 'Remaining budget'
        st.markdown(f'<div class="budget-panel"><div class="budget-top"><div><div class="budget-title">Budget tracking</div>'
                    f'<div class="budget-copy">Spent {rupees(current_expense)} of {rupees(current_budget)}</div></div>'
                    f'<div class="budget-remaining" style="color:{color}">{rupees(abs(current_budget-current_expense))}'
                    f'<div class="budget-copy">{remaining_label}</div></div></div>'
                    f'<div class="budget-track" role="progressbar" aria-label="Monthly budget usage" aria-valuenow="{min(ratio*100,100):.1f}" aria-valuemin="0" aria-valuemax="100">'
                    f'<div class="budget-fill" style="width:{min(ratio*100,100):.1f}%;background:{color}"></div></div>'
                    f'<div class="budget-status" style="color:{color}">{ratio:.0%} used · {status}</div></div>', unsafe_allow_html=True)
    else:
        st.info('Set your monthly budget in the Monthly plan tab to start tracking your spending allowance.')


def entry_fields(entry, prefix):
    """Reusable editable preview. Empty intent and date require a user choice."""
    c1, c2, c3 = st.columns(3)
    intents = ['Choose intent', 'Expense', 'Income', 'Reminder']
    current = entry.get('intent') or 'Choose intent'
    intent = c1.selectbox('Intent', intents, index=intents.index(current), key=prefix+'_intent')
    amount = c2.number_input('Amount (₹)', min_value=0.0, max_value=1e9,
                            value=float(entry['amount']) if entry.get('amount') is not None and 0 < entry['amount'] <= 1e9 else 0.0,
                            step=1.0, format='%.2f', key=prefix+'_amount')
    day = c3.date_input('Date / reminder due date', value=entry.get('date'), key=prefix+'_date')
    description = st.text_input('Description', value=entry.get('description', ''), key=prefix+'_description')
    category = st.selectbox('Category', CATEGORIES, index=CATEGORIES.index(entry.get('category', 'Other')), key=prefix+'_category')
    return dict(intent=intent, amount=amount, date=day, description=description, category=category)


def save_preview(prefix):
    edited = {field: st.session_state[prefix + '_' + field]
              for field in ('intent', 'amount', 'date', 'description', 'category')}
    errors = validate_entry(edited)
    if errors:
        st.session_state.preview_errors = errors
    else:
        db.save_entry(edited)
        st.session_state.pop('preview', None)
        st.session_state.pop('preview_errors', None)
        st.session_state.notice = 'Entry saved successfully.'


with st.container():
    st.subheader('Add an expense, income, or reminder')
    sentence = st.text_area('Transaction or reminder', placeholder='Spent ₹300 on pizza today', key='sentence')
    st.caption('Try: “Received Rs 20000 salary today” or “Remind me to pay ₹1200 electricity bill tomorrow”.')
    if st.button('Extract details', type='primary'):
        if not sentence.strip():
            st.error('Enter a sentence first.')
        else:
            st.session_state.pop('preview_errors', None)
            st.session_state.preview = parse_entry(sentence)
            st.session_state.preview_version = st.session_state.get('preview_version', 0) + 1
    if 'preview' in st.session_state:
        st.subheader('Review before saving')
        st.caption('Check the suggested details and make any corrections before saving.')
        for warning in st.session_state.preview.get('warnings', []):
            st.warning(warning)
        for error in validate_entry(st.session_state.preview):
            st.warning(error)
        for error in st.session_state.get('preview_errors', []):
            st.error(error)
        prefix = 'preview_' + str(st.session_state.preview_version)
        with st.form('preview_form'):
            entry_fields(st.session_state.preview, prefix)
            st.form_submit_button('Save transaction', type='primary',
                                  on_click=save_preview, args=(prefix,))

dashboard(month)
income, expense = db.monthly_summary(frame, month)

history_tab, reminders_tab, insights_tab, plan_tab = st.tabs([
    '📒 History & edit', '🔔 Bill reminders', '📊 Insights & export', '▣ Monthly plan'
])

with plan_tab:
    st.subheader('Your monthly plan')
    st.caption('Choose the month shown on your dashboard and set its spending budget.')
    selected_month = st.date_input('Select a month', value=date.today(), key='month')
    with st.form('budget_form'):
        st.number_input('Monthly budget (₹)', min_value=0.0, max_value=1e9,
                        value=budget, step=100.0, key=f'budget_{month}')
        st.form_submit_button('Save budget', on_click=save_budget, args=(month,))
    st.caption('Set a budget to see your remaining spending allowance.')
    st.caption('Reminders refresh every minute while this app is open. Alerts appear here; mobile and email notifications are not sent.')
    st.button('Refresh reminders', on_click=lambda: None)

def close_editor():
    st.session_state.pop('editor_id', None)


def open_editor(entry_id):
    st.session_state.editor_id = entry_id


@st.dialog('Edit entry', width='large', on_dismiss=close_editor)
def edit_dialog(entry_id):
    """Keep editing out of the browsing flow; commit changes with a full rerun."""
    records = db.list_entries()
    matches = records[records.id == entry_id]
    if matches.empty:
        st.info('This entry has already been removed.')
        close_editor()
        return
    row = matches.iloc[0]
    st.caption(f'{row.description} · {rupees(row.amount)}')
    locked = bool(row.paid) or pd.notna(row.source_reminder_id)
    if locked:
        st.info('Completed bill payments are locked for editing. Deleting a payment reopens its reminder; deleting a paid reminder keeps its payment.')
    else:
        original = row.to_dict()
        original['date'] = date.fromisoformat(original['date'])
        with st.form(f'edit_form_{entry_id}'):
            edited = entry_fields(original, f'edit_{entry_id}')
            save = st.form_submit_button('Save changes', type='primary')
        if save:
            errors = validate_entry(edited)
            for error in errors:
                st.error(error)
            if not errors:
                db.save_entry(edited, entry_id)
                st.session_state.notice = 'Changes saved.'
                close_editor()
                st.rerun()
    with st.expander('Delete this entry'):
        st.caption('This permanently removes the entry from your history.')
        confirm = st.checkbox('Confirm deletion of this entry', key=f'delete_check_{entry_id}')
        if st.button('Delete selected entry', disabled=not confirm, key=f'delete_{entry_id}'):
            db.delete_entry(entry_id)
            st.session_state.notice = 'Entry deleted.'
            close_editor()
            st.rerun()


def finance_row(row, location, reminder=False, completed=False):
    """One readable row, with details together and a clear action on the right."""
    day = date.fromisoformat(row.date)
    sign = '+' if row.intent == 'Income' else '−' if row.intent == 'Expense' else ''
    if reminder:
        days = (day - date.today()).days
        status = 'Paid' if completed else 'Overdue' if days < 0 else 'Due today' if days == 0 else 'Due soon' if days <= 3 else 'Upcoming'
        tone = 'paid' if completed else 'overdue' if days < 0 else 'urgent' if days <= 3 else ''
        meta = f'Due {day:%d %b %Y} &nbsp; · &nbsp; <span class="finance-status {tone}">{status}</span>'
    else:
        meta = f'{day:%d %b %Y} · {escape(row.category)} · {row.intent}'
    with st.container(key=f'finance-row-{location}-{row.id}'):
        detail, action = st.columns([6, 1], vertical_alignment='center')
        detail.markdown(f'<div class="finance-item"><div class="finance-main"><div class="finance-name">{escape(row.description)}</div>'
                        f'<div class="finance-amount {row.intent.lower()}">{sign}{rupees(row.amount)}</div></div>'
                        f'<div class="finance-meta">{meta}</div></div>', unsafe_allow_html=True)
        if reminder and not completed:
            action.button('Mark paid', key=f'paid_{row.id}', on_click=pay_reminder, args=(int(row.id),), type='primary', width='stretch')
        action.button('Edit', key=f'open_{location}_{row.id}', on_click=open_editor, args=(int(row.id),), width='stretch')


with history_tab:
    st.subheader('History')
    st.caption('Your recorded income and expenses. Choose Edit only when you need to make a change.')
    search_col, type_col = st.columns([3, 1])
    search = search_col.text_input('Search history', placeholder='Find a transaction…', key='history_search', label_visibility='collapsed')
    kind = type_col.selectbox('Transaction type', ['All transactions', 'Expenses', 'Income'], key='history_type', label_visibility='collapsed')
    visible = frame[frame.intent != 'Reminder'].copy()
    if kind != 'All transactions':
        visible = visible[visible.intent == ('Expense' if kind == 'Expenses' else 'Income')]
    if search.strip():
        visible = visible[visible.description.str.contains(search.strip(), case=False, regex=False)]
    visible = visible.sort_values(['date', 'id'], ascending=False)
    filter_key = (search, kind)
    if st.session_state.get('history_view_filter') != filter_key:
        st.session_state.history_view_filter = filter_key
        st.session_state.history_limit = 10
    limit = st.session_state.get('history_limit', 10)
    if visible.empty:
        st.info('No matching transactions. Try another search.' if search.strip() or kind != 'All transactions' else 'No transactions yet. Add your first expense above.')
    else:
        st.caption(f'{len(visible)} transactions · Newest first')
        for row in visible.head(limit).itertuples():
            finance_row(row, 'history')
        if len(visible) > limit:
            def show_more():
                st.session_state.history_limit = limit + 10
            st.button('Show more transactions', on_click=show_more)

with reminders_tab:
    st.subheader('Bill reminders')
    st.caption('See what is due and mark a bill paid after you have paid it.')
    reminders = frame[frame.intent == 'Reminder'].copy()
    pending = reminders[reminders.paid == 0].sort_values(['date', 'id'])
    completed = reminders[reminders.paid == 1].sort_values(['date', 'id'], ascending=False)
    if pending.empty:
        st.success('You’re all caught up. No bills waiting for payment.')
    else:
        st.caption(f'{len(pending)} unpaid bills · Earliest due first')
        for row in pending.itertuples():
            finance_row(row, 'reminders', reminder=True)
        st.caption('Mark paid also records the bill as an expense and updates your balance.')
    if not completed.empty:
        with st.expander(f'Paid bills ({len(completed)})'):
            for row in completed.itertuples():
                finance_row(row, 'completed', reminder=True, completed=True)

with insights_tab:
    st.subheader(f'Spending insights · {month}')
    monthly = frame[frame.date.str.startswith(month)]
    spending = monthly[monthly.intent == 'Expense'].groupby('category', as_index=False).amount_paise.sum()
    if not spending.empty:
        spending['amount'] = spending.amount_paise / 100
        st.plotly_chart(px.pie(spending, names='category', values='amount', hole=.55,
                               title='Spending by category (₹ INR)', color_discrete_sequence=px.colors.qualitative.Safe), use_container_width=True)
    else:
        st.info('No expenses recorded for this month.')
    comparison = pd.DataFrame({'Type': ['Income', 'Expense'], 'Amount': [income, expense]})
    st.plotly_chart(px.bar(comparison, x='Type', y='Amount', color='Type',
                           title='Income versus expenses (₹ INR)', color_discrete_map={'Income': '#16a085', 'Expense': '#e67e22'}), use_container_width=True)
    st.caption('Charts and totals include actual transactions only; unpaid reminders do not count as spending.')
    export_frame = frame[['id', 'intent', 'amount', 'date', 'description', 'category', 'paid', 'source_reminder_id']].copy()
    # Avoid spreadsheet formula execution when an exported description starts with a formula marker.
    export_frame['description'] = export_frame.description.map(lambda x: "'" + x if x.lstrip().startswith(('=', '+', '-', '@')) else x)
    st.download_button('Download all history as CSV', export_frame.to_csv(index=False).encode('utf-8-sig'),
                       file_name='expense_history.csv', mime='text/csv')

if 'editor_id' in st.session_state:
    edit_dialog(st.session_state.editor_id)
