# Verification results

Verified on 12 October 2026 using Python 3.9.6 on macOS Apple Silicon.
Dependencies remain installed in the workspace work/.venv. Exact versions are
recorded in requirements-lock.txt.

## Functional tests

Final command from the project folder:

```bash
python -m pytest -q
```

**85 passed in 2.98 seconds.** All four required acceptance examples pass.
The expanded suite covers currency formats, multiple amounts and dates, mixed
and negated intents, supported spelling variants, year boundaries, leap years,
invalid dates, unknown vocabulary, model training, dataset separation, CRUD,
SQLite persistence, budgets, exact paise totals, and idempotent bill payments.
Seven Streamlit AppTest scenarios exercise saving/editing/paying, invalid-field
correction, missing-date rejection, budget/deletion behaviour, month switching,
ambiguous amount correction, and oversized amount rejection.

## Training and category evaluation

```bash
python train_model.py
python evaluate_model.py --baseline models/baseline_150.joblib
```

- Active training corpus: 400 rows, 40 per category.
- Separate fixed evaluation corpus: 100 rows, ten per category.
- Exact normalised duplicates/overlap: none.
- Three-fold stratified cross-validation on training: 91.7% accuracy.
- Expanded model on the separate set: 98/100 correct, macro F1 0.980.
- Earlier 150-row model on the same set: 88/100 correct.
- Model hyperparameters stayed unchanged. No evaluation examples were moved
  into training and no holdout-driven hyperparameter tuning occurred.
- The two errors remain in evaluation/predictions.csv. See metrics.json for
  per-class metrics, confusion matrix, dataset counts, and SHA-256 hashes.

These are category scores on small synthetic datasets, not estimates for
unrestricted real user sentences or every extraction field. No exact overlap
does not imply absence of semantic similarity. If the current holdout later
guides development, reserve a new untouched test set.

## Application startup and browser verification

The actual Streamlit server was started successfully. The earlier initial
version's health endpoint returned ok. For the updated version, an isolated
copy ran at http://127.0.0.1:8502 with synthetic demonstration records. Browser
inspection confirmed pizza extraction (Expense, 300, Food, local today), the
editable preview, upcoming and overdue bill records, budget warnings, spending
charts, and the CSV control. Screenshots in docs/assets came from that isolated
copy. The delivered user database was not changed for these screenshots.

The temporary demo server was stopped after verification. Use the README
startup command for the normal app at http://127.0.0.1:8501.

## Submission materials

The Word report and presentation include the updated data protocol and results.
The presentation includes editable text/tables/chart data and speaker notes.
PDF copies and a viva/demo guide accompany the editable files. The report and
slides were rendered and visually reviewed before packaging.
