# Smart Expense Tracker and Bill Reminder Using Natural Language Processing

A complete college project using Python, Streamlit, pandas, scikit-learn,
dateparser, SQLite, Plotly, joblib, and pytest. Runs locally and offline after
package installation. No external AI API, API key, GPU, LLM, transformers,
Ollama, spaCy model, or downloaded pretrained language model is used.

## Installation and startup

**New to computers?** Start with [the beginner Windows guide](BEGINNER_WINDOWS_GUIDE.md)
or `BEGINNER_WINDOWS_GUIDE.pdf`. After installing the Python manager, double-click
`SETUP_WINDOWS.bat` once, then `START_WINDOWS.bat` whenever you want to use the app.

**Moving to a Windows laptop?** Follow [the Windows guide](WINDOWS_SETUP.md),
or open `WINDOWS_SETUP.pdf`. It includes the exact commands and explains
`SETUP_WINDOWS.bat` (first installation) and `START_WINDOWS.bat` (later launches).

Python 3.9–3.12 is recommended. From a terminal:

```bash
cd "/Users/xplore/Documents/Codex/2026-10-12/build-a-complete-college-project-titled-4/outputs/smart-expense-tracker"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train_model.py
python evaluate_model.py --baseline models/baseline_150.joblib
python -m pytest -q
python -m streamlit run app.py
```

Open http://127.0.0.1:8501. Stop the server with Ctrl+C.
For Windows, follow `WINDOWS_SETUP.md`; it selects Python 3.12 and uses the
environment executable directly, without activation. If moving the project,
use its new folder path. SQLite is part of Python and needs no pip package.

The model is included in `models/category_model.joblib`. The explicit training
command regenerates it with your installed scikit-learn version. If it is
missing, the application trains automatically on first extraction. Only load
trusted joblib artifacts. To resolve version incompatibility, rerun
`python train_model.py`. `requirements-lock.txt` records the exact environment
used for verification; the regular requirements use compatible version ranges.

An environment was also installed during project creation at `../../work/.venv`.
To start immediately from the project folder without reinstalling:

```bash
../../work/.venv/bin/python -m streamlit run app.py
```

## How to use

1. Enter one expense, income, or reminder sentence in the entry box at the top.
2. Click **Extract details**. Review intent, amount, date, description, and category.
3. Click **Save transaction**. Invalid fields prevent saving and show errors.
4. **History & edit** lists recorded transactions. Click **Edit** beside a row
   to open its pop-up. Save changes, or expand deletion and confirm it.
5. **Bill reminders** lists unpaid bills. **Mark paid** records the expense;
   completed bills appear under **Paid bills**.
6. **Monthly plan** contains the reporting month selector and budget settings.
   **Insights & export** contains monthly charts and CSV export.

Try these examples:

| Sentence | Intent | Amount | Category | Date |
| --- | --- | ---: | --- | --- |
| Spent ₹300 on pizza today | Expense | 300 | Food | Today |
| Paid 500 for bus travel yesterday | Expense | 500 | Transport | Yesterday |
| Received Rs 20000 salary today | Income | 20000 | Salary | Today |
| Remind me to pay electricity bill of ₹1200 tomorrow | Reminder | 1200 | Utilities | Tomorrow |
| Add a reminder for my internet bill of ₹799 next Friday | Reminder | 799 | Utilities | Next Friday |

## Behaviour and validation

- Currency is INR. Amounts support ₹, Rs, Rs., INR, comma groups like 15,000,
  and plain numbers. Values must be positive, at most two decimal places,
  and no more than ₹1,000,000,000. Refunds can be entered as positive income.
- Currency-marked amounts take precedence over other numbers. Dates are
  removed before looking for plain numeric amounts. One entry per sentence
  is supported. Several currency amounts (or several plain numeric candidates)
  leave the amount blank and show a warning. Split those payments or deliberately
  correct the preview. One currency amount takes precedence over quantities.
- Explicit dates support English month names, ISO YYYY-MM-DD, and DD/MM/YYYY.
  Relative dates use the computer's local date. “Next Friday” means the next
  occurrence, seven days later if today is Friday. Yearless reminder dates
  prefer the future. Transactions without a date default to today; reminders
  require a recognised or manually selected date. Invalid explicit dates
  remain blank. Multiple recognised dates also leave the date blank for review.
  All extracted fields are editable.
- Supported negations and mixed income/expense signals leave intent blank.
  Reminder rules otherwise take precedence over payment words. Unknown intent
  remains blank; review the sentence and choose it manually to save.
- Reminders may be in the past so overdue bills can be tracked.
- Paying a reminder atomically marks it paid and creates one expense dated
  today. A second payment attempt cannot create another expense. Unpaid
  reminders do not count in totals. If a bill was already recorded manually,
  avoid also marking a duplicate reminder paid.
- Paid reminders and linked expenses are locked against editing to preserve
  consistency. Delete the linked expense to reopen its reminder. Deleting a
  paid reminder keeps its actual expense and removes the link.
- Budget ₹0 means no budget warning. Budgets are saved separately per month.
- Monthly metrics use the selected calendar month; the history and export
  include all dates. Dates have no time component. No automatic recurring bills.
- Alerts appear **inside the app while it is running and opened**. Dashboard
  alerts refresh every minute; refresh the page to update other views. No background, email, or mobile
  notifications. The Windows launch script disables Streamlit usage telemetry.

## NLP and machine learning

`nlp.py` applies regular expressions for monetary amounts and intent keywords,
recognises supported date phrases, and sends them to dateparser. An explicit
weekday rule resolves “next Friday”. Description cleanup removes recognised
amounts, dates, and common action phrases.

`train_model.py` trains a scikit-learn Pipeline: TfidfVectorizer with lowercase
conversion, standard word tokenization, English stop-word removal, unigrams
and bigrams, followed by LogisticRegression. The dataset is 400 manually
labelled teaching examples, 40 per category. A separate evaluation CSV contains
100 descriptions, ten per category, that are never used for fitting. Categories: Food, Transport,
Shopping, Utilities, Rent, Healthcare, Education, Entertainment, Salary, Other.
The model and vocabulary are built entirely from the included CSV. Predictions
are suggestions, particularly for unfamiliar words; correct them before saving.
The training script reports three-fold stratified cross-validation accuracy.
This small synthetic dataset is not a claim of real-world production accuracy.

## Project structure

```text
app.py                     Streamlit interface and charts
nlp.py                     extraction and shared entry validation
database.py                SQLite persistence and reminder/budget operations
train_model.py             train, evaluate, save, and load local pipeline
data/training.csv          400 labelled training examples
data/evaluation.csv        100 separate evaluation descriptions
data/baseline_training_150.csv  original corpus retained for provenance
evaluate_model.py          dataset audit and held-out category evaluation
evaluation/                metrics, predictions, classification report and confusion matrix
docs/                      Word/PDF report, PowerPoint/PDF, speaker notes and viva guide
models/category_model.joblib  generated classifier
.streamlit/config.toml     theme and minimal toolbar
tests/                     NLP, database, and Streamlit workflow tests
requirements.txt           compatible package requirements
requirements-lock.txt      tested environment versions
README.md                  setup and user guide
PROJECT_REPORT.md          academic project report
VERIFICATION.md            actual verification results
```

`data/expenses.db` is created on startup. File paths are resolved relative to
the code, so data survives app restarts. Money is stored as integer paise to
avoid floating-point sum drift. Back up the SQLite file with the server stopped.
For a fresh demonstration, stop the app and remove only `data/expenses.db`.
Tests use temporary databases and do not change your actual history.

## Testing

```bash
python -m pytest -q
python train_model.py
```

Tests cover all four required acceptance examples with a fixed date, currency
and date formats, missing/invalid fields, local/automatic training, database
CRUD and persistence, exact paise totals, budget settings, overdue/due/upcoming
status, idempotent payments, and Streamlit form workflows. See VERIFICATION.md
for the results from this delivery. No internet is used by the application
logic or tests. Installation alone needs a package source.

## Scope

This is a single-user local teaching application, without authentication,
cloud sync, encryption, bank integration, or receipt OCR. Do not expose it as a
public financial service. Future work can expand the labelled dataset, support
more languages/date formats, and add local recurring reminders.

## Expanded dataset and measured results

The updated model was fitted only on the 400-row training file. The 100-row
evaluation file was authored separately and fixed before measurement. Dataset
audits reject exact normalised duplicates, invalid labels, and cross-file
overlap. This does not rule out semantic similarity within synthetic examples.

- Expanded model: **98/100 correct**, macro F1 **0.980** on the separate set.
- Earlier 150-row model: **88/100 correct** on that same set.
- Three-fold stratified training cross-validation: **91.7% accuracy**.
- Functional verification: **92 tests passed** on the development Mac;
  see `UI_VERIFICATION.md` for current UI checks.

These results measure category classification on small synthetic descriptions.
They do not establish accuracy for unrestricted user sentences or real financial
data. The two evaluation errors remain visible in `evaluation/predictions.csv`.
No test examples were added to training to hide those errors.

```bash
python train_model.py
python evaluate_model.py --baseline models/baseline_150.joblib
python -m pytest -q
```

The optional baseline artifact and its original CSV are retained for comparison.
The application loads only `models/category_model.joblib`. Re-running evaluation
without `--baseline` reports only the current model. The evaluation script never
fits or tunes the classifier. It also records dataset/model SHA-256 hashes.

When changing training.csv, retrain explicitly. If the current evaluation set
guides changes, treat it as a development set and reserve a fresh test set.
Changes made in the application do not automatically retrain the classifier.

## College submission materials

- `docs/PROJECT_REPORT.docx` and `.pdf`: academic report with architecture,
  database design, dataset protocol, results, errors, screenshots, and references.
- `docs/PROJECT_PRESENTATION.pptx` and `.pdf`: 17-slide presentation.
- `docs/SPEAKER_NOTES.md`: slide-by-slide explanation, also embedded in PowerPoint.
- `docs/VIVA_AND_DEMO.md`: 28 viva questions and a demonstration script.

Replace student, college, roll number, guide, and other cover placeholders before
submission. Screenshots use a separate synthetic demo database, not personal
financial records.
