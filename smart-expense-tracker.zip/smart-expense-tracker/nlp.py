"""Explainable rules for intent, amounts and dates; ML for categories."""
import re
from datetime import date, datetime, timedelta
from functools import lru_cache
import dateparser
from train_model import CATEGORIES, load_model

NUMBER = r'(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?'
MONEY = re.compile(r'(?:₹|\brs\.?|\binr)\s*(' + NUMBER + r')(?![\d.])', re.I)
MONTHS = r'January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec'
DATE_PATTERN = re.compile(
    r'\b(?:next\s+(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)|'
    r'day after tomorrow|day before yesterday|today|yesterday|tomorrow|'
    r'\d{4}-\d{1,2}-\d{1,2}|\d{1,2}/\d{1,2}/\d{4}|'
    r'\d{1,2}(?:st|nd|rd|th)?\s+(?:' + MONTHS + r')(?:\s+\d{4})?|'
    r'(?:' + MONTHS + r')\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?)\b', re.I)


def extract_intent(text):
    # Negated transactions are ambiguous. Leave intent blank for manual review.
    if re.search(r"\b(?:did not|do not|have not|has not|not yet|never|didn't|don't|haven't|hasn't)\b", text, re.I):
        return None
    if re.search(r'\b(remind|reminder|due)\b', text, re.I):
        return 'Reminder'
    income = bool(re.search(r'\b(received|recieved|earned|income|credited|salary|salery|stipend|wages)\b', text, re.I))
    expense = bool(re.search(r'\b(spent|spend|paid|pay|bought|purchased|expense)\b', text, re.I))
    if income and expense:
        return None
    return 'Income' if income else 'Expense' if expense else None


def extract_date(text, intent, today=None):
    today = today or date.today()
    matches = list(DATE_PATTERN.finditer(text))
    match = matches[0] if matches else None
    if len(matches) > 1:
        return None, match
    if not match:
        return None, None
    phrase = match.group()
    # dateparser's handling of "next Friday" varies: determine the next occurrence
    # explicitly, then still parse the resulting ISO date with dateparser.
    next_day = re.fullmatch(r'next\s+(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)', phrase, re.I)
    if next_day:
        weekdays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        offset = (weekdays.index(next_day[1].lower()) - today.weekday()) % 7 or 7
        phrase = (today + timedelta(days=offset)).isoformat()
    parsed = dateparser.parse(phrase, languages=['en'], settings={
        'RELATIVE_BASE': datetime.combine(today, datetime.min.time()),
        'PREFER_DATES_FROM': 'future' if intent == 'Reminder' else 'current_period',
        'PREFER_LOCALE_DATE_ORDER': False,
        'DATE_ORDER': 'YMD' if re.fullmatch(r'\d{4}-\d{1,2}-\d{1,2}', phrase) else 'DMY', 'RETURN_AS_TIMEZONE_AWARE': False,
    })
    return (parsed.date() if parsed else None), match


def extract_amount(text):
    # Never guess between several monetary values. The preview stays editable.
    currencies = list(re.finditer(r'(?:₹|\brs\.?|\binr)\s*([+-]?[\d,.]+)', text, re.I))
    if len(currencies) > 1:
        return None
    if currencies:
        candidate = currencies[0][1]
    else:
        without_dates = DATE_PATTERN.sub(' ', text)
        numbers = list(re.finditer(r'(?<!\w)([+-]?\d[\d,.]*)(?!\w)', without_dates))
        if len(numbers) != 1:
            return None
        candidate = numbers[0][1]
    # A comma or full stop after an integer can be sentence punctuation.
    if candidate.endswith(',') or (candidate.endswith('.') and candidate.count('.') == 1):
        candidate = candidate.rstrip('.,')
    if not re.fullmatch(r'[+-]?' + NUMBER, candidate):
        return None
    return float(candidate.replace(',', ''))


@lru_cache(maxsize=1)
def category_model():
    return load_model()


def parse_entry(text, today=None):
    intent = extract_intent(text)
    parsed_date, date_match = extract_date(text, intent, today)
    description = DATE_PATTERN.sub('', text)
    description = MONEY.sub('', description)
    description = re.sub(r'(?<!\w)' + NUMBER + r'(?!\w)', '', description)
    description = re.sub(r'\b(remind me to|add a reminder for|reminder for|i spent|spent|paid|received|pay)\b', '', description, flags=re.I)
    description = re.sub(r'\s+', ' ', description).strip(' .,!')
    description = description or text.strip()
    model = category_model()
    features = model.named_steps['tfidf'].transform([description])
    category = str(model.predict([description])[0]) if features.nnz else 'Other'
    warnings = []
    if len(DATE_PATTERN.findall(text)) > 1:
        warnings.append('Several dates were found. Choose one date or split this into separate entries.')
    if extract_amount(text) is None:
        warnings.append('No single valid amount was found. Enter one amount or split multiple payments into separate entries.')
    if intent is None:
        warnings.append('The intent is unknown, mixed, or negated. Review the sentence and choose the correct intent.')
    return {'intent': intent, 'amount': extract_amount(text),
            'date': parsed_date if date_match else (None if intent == 'Reminder' else today or date.today()),
            'description': description, 'category': category, 'warnings': warnings}


def validate_entry(entry):
    errors = []
    if entry.get('intent') not in ('Expense', 'Income', 'Reminder'):
        errors.append('Choose an intent: Expense, Income, or Reminder.')
    try:
        from decimal import Decimal, InvalidOperation
        amount = Decimal(str(entry.get('amount')))
        if not amount.is_finite() or amount <= 0 or amount > Decimal('1000000000') or amount != amount.quantize(Decimal('.01')):
            raise ValueError
    except (ValueError, TypeError, InvalidOperation):
        errors.append('Enter a positive amount with at most two decimal places (maximum ₹1,000,000,000).')
    if not isinstance(entry.get('date'), date):
        errors.append('Choose a valid due date for the reminder.' if entry.get('intent') == 'Reminder' else 'Choose a valid transaction date.')
    if not str(entry.get('description') or '').strip():
        errors.append('Enter a description.')
    if entry.get('category') not in CATEGORIES:
        errors.append('Choose a supported category.')
    return errors
