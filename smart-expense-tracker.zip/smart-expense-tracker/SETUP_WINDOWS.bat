@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto failed
if not exist "app.py" goto missing_project
if not exist "requirements.txt" goto missing_project
echo Checking Python...
py -3.12 --version >nul 2>&1
if not errorlevel 1 goto python_ready
where pymanager >nul 2>&1
if errorlevel 1 goto missing_python
echo Installing Python 3.12. Keep internet connected and wait...
pymanager install 3.12
if errorlevel 1 goto failed
py -3.12 --version
if errorlevel 1 goto missing_python
:python_ready
if exist ".venv\Scripts\python.exe" goto install_packages
if exist ".venv" goto wrong_environment
py -3.12 -m venv .venv
if errorlevel 1 goto failed
:install_packages
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" train_model.py
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 goto failed
echo Setup complete. Double-click START_WINDOWS.bat to open the app.
pause
exit /b 0
:missing_python
echo Python was not found. Install the Python install manager from python.org.
echo Restart Windows, then double-click SETUP_WINDOWS.bat again.
echo See BEGINNER_WINDOWS_GUIDE.pdf for the steps.
pause
exit /b 1
:wrong_environment
echo This .venv is not a Windows environment. Create a new Windows environment.
echo Keep your data folder safe. See WINDOWS_SETUP.md for help.
pause
exit /b 1
:missing_project
echo Extract the whole ZIP and keep this script beside app.py and requirements.txt.
pause
exit /b 1
:failed
echo Setup stopped because a command failed. Read the error above before retrying.
pause
exit /b 1
