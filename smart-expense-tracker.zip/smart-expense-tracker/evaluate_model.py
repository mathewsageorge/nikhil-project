"""Evaluate a frozen trained classifier on a separate, never-fitted dataset."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import joblib
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from train_model import CATEGORIES, DATASET_PATH, MODEL_PATH, ROOT, load_model

EVALUATION_PATH = ROOT / 'data' / 'evaluation.csv'
RESULTS_DIR = ROOT / 'evaluation'


def normalise_description(text):
    return re.sub(r'[^a-z0-9]+', ' ', str(text).lower()).strip()


def audit_datasets(training_path=DATASET_PATH, evaluation_path=EVALUATION_PATH):
    training, evaluation = pd.read_csv(training_path), pd.read_csv(evaluation_path)
    sets = []
    for name, frame in [('training', training), ('evaluation', evaluation)]:
        if list(frame.columns) != ['description', 'category'] or frame.isna().any().any():
            raise ValueError(f'{name} CSV needs non-empty description and category columns.')
        if set(frame.category) != set(CATEGORIES):
            raise ValueError(f'{name} CSV must contain all supported categories.')
        values = frame.description.map(normalise_description)
        if values.eq('').any() or values.duplicated().any():
            raise ValueError(f'{name} CSV contains empty or duplicate descriptions.')
        sets.append(set(values))
    if sets[0] & sets[1]:
        raise ValueError('Training and evaluation descriptions overlap. Keep evaluation separate.')
    return training, evaluation


def score_model(model, evaluation):
    """Predict only. No fit, vocabulary update, or hyperparameter selection."""
    predictions = model.predict(evaluation.description)
    return {
        'accuracy': float(accuracy_score(evaluation.category, predictions)),
        'macro_f1': float(f1_score(evaluation.category, predictions, labels=CATEGORIES, average='macro', zero_division=0)),
        'classification_report': classification_report(evaluation.category, predictions, labels=CATEGORIES, output_dict=True, zero_division=0),
        'confusion_matrix': confusion_matrix(evaluation.category, predictions, labels=CATEGORIES).tolist(),
    }, predictions


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def evaluate(baseline_path=None, results_dir=RESULTS_DIR):
    training, evaluation = audit_datasets()
    model = load_model()
    metrics, predictions = score_model(model, evaluation)
    results = {
        'training_rows': len(training), 'evaluation_rows': len(evaluation),
        'categories': CATEGORIES, 'training_counts': training.category.value_counts().to_dict(),
        'evaluation_counts': evaluation.category.value_counts().to_dict(),
        'dataset_sha256': {'training': sha256(DATASET_PATH), 'evaluation': sha256(EVALUATION_PATH)},
        'model_sha256': sha256(MODEL_PATH),
        'method': 'Fixed separate synthetic evaluation set. Fit only on training.csv. No holdout-driven tuning.',
        'current_model': metrics,
    }
    if baseline_path:
        # Only load trusted artifacts. This optional artifact predates expansion.
        baseline_metrics, _ = score_model(joblib.load(baseline_path), evaluation)
        results['baseline_150_rows'] = baseline_metrics
        results['baseline_model_sha256'] = sha256(baseline_path)
    results_dir = Path(results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / 'metrics.json').write_text(json.dumps(results, indent=2) + '\n')
    output = evaluation.copy()
    output['predicted_category'] = predictions
    output['correct'] = output.category == output.predicted_category
    output.to_csv(results_dir / 'predictions.csv', index=False)
    matrix = pd.DataFrame(metrics['confusion_matrix'], index=CATEGORIES, columns=CATEGORIES)
    matrix.index.name = 'actual_category'
    matrix.to_csv(results_dir / 'confusion_matrix.csv')
    pd.DataFrame(metrics['classification_report']).T.to_csv(results_dir / 'classification_report.csv', index_label='category')
    print(f"Training rows: {len(training)}; separate evaluation rows: {len(evaluation)}")
    print(f"Evaluation accuracy: {metrics['accuracy']:.1%}; macro F1: {metrics['macro_f1']:.3f}")
    if baseline_path:
        print(f"Original 150-row model on same set: {results['baseline_150_rows']['accuracy']:.1%}")
    print(f'Results saved to {results_dir}')
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, help='Optional trusted baseline joblib artifact')
    args = parser.parse_args()
    evaluate(args.baseline)
