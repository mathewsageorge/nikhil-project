@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto failed
if not exist "app.py" goto missing_project
if not exist ".venv\Scripts\python.exe" goto missing_setup
echo Open http://127.0.0.1:8501 in your browser.
echo Keep this window open. Press Ctrl+C to stop the app.
".venv\Scripts\python.exe" -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
if errorlevel 1 goto failed
exit /b 0
:missing_setup
echo Run SETUP_WINDOWS.bat first. See WINDOWS_SETUP.md for the Python installation steps.
pause
exit /b 1
:missing_project
echo Keep this script in the extracted project folder beside app.py.
pause
exit /b 1
:failed
echo The app stopped with an error. Read the message above or consult WINDOWS_SETUP.md.
pause
exit /b 1
