from datetime import date, timedelta
import pytest
from nlp import parse_entry, extract_amount, validate_entry
from train_model import train_model

TODAY = date(2026, 10, 12)

@pytest.mark.parametrize('text,intent,amount,category,offset', [
    ('Spent ₹300 on pizza today', 'Expense', 300, 'Food', 0),
    ('Paid 500 for bus travel yesterday', 'Expense', 500, 'Transport', -1),
    ('Received Rs 20000 salary today', 'Income', 20000, 'Salary', 0),
    ('Remind me to pay electricity bill of ₹1200 tomorrow', 'Reminder', 1200, 'Utilities', 1),
])
def test_acceptance(text, intent, amount, category, offset):
    result = parse_entry(text, TODAY)
    assert result['intent'] == intent
    assert result['amount'] == amount
    assert result['category'] == category
    assert result['date'] == TODAY + timedelta(days=offset)
    assert validate_entry(result) == []

@pytest.mark.parametrize('text,amount', [
    ('Paid ₹1,500 for electricity', 1500), ('Paid Rs. 600 for petrol', 600),
    ('Received INR 15,000 salary', 15000), ('Paid 250.50 for lunch', 250.50),
    ('Paid ₹250.50 for lunch.', 250.50), ('Paid 500 for lunch.', 500),
    ('Remind me about bill on 20 October', None), ('Paid on 2026-10-20', None),
    ('Paid ₹-500 for petrol', -500), ('Paid -500 for petrol', -500),
    ('Paid ₹1,20 for petrol', None), ('Paid ₹12.345 for food', None),
])
def test_amount_formats(text, amount):
    assert extract_amount(text) == amount

@pytest.mark.parametrize('phrase,expected', [
    ('next Friday', date(2026, 10, 16)), ('20 October', date(2026, 10, 20)),
    ('tomorrow', date(2026, 10, 13)), ('2026-10-20', date(2026, 10, 20)),
    ('20/10/2026', date(2026, 10, 20)), ('day after tomorrow', date(2026, 10, 14)),
])
def test_dates(phrase, expected):
    assert parse_entry('Remind me to pay ₹799 internet bill ' + phrase, TODAY)['date'] == expected

def test_next_friday_on_friday():
    assert parse_entry('Reminder ₹799 internet bill next Friday', date(2026, 10, 16))['date'] == date(2026, 10, 23)

@pytest.mark.parametrize('text', [
    'pizza ₹300 today', 'Spent on pizza today', 'Spent ₹0 today',
    'Spent ₹-20 today', 'Remind me to pay ₹1200 electricity bill',
    'Remind me to pay ₹1200 electricity bill on 31 February',
])
def test_invalid_entries(text):
    assert validate_entry(parse_entry(text, TODAY))

def test_undated_transaction_defaults_today():
    assert parse_entry('Spent ₹30 on coffee', TODAY)['date'] == TODAY

def test_local_training(tmp_path):
    path = tmp_path / 'model.joblib'
    model = train_model(path)
    assert path.exists()
    assert model.predict(['pizza lunch'])[0] == 'Food'

def test_auto_training(monkeypatch, tmp_path):
    import train_model as training
    monkeypatch.setattr(training, 'MODEL_PATH', tmp_path / 'absent.joblib')
    # Explicitly use patched path because default arguments bind at definition.
    monkeypatch.setattr(training, 'train_model', lambda: train_model(training.MODEL_PATH))
    assert training.load_model().predict(['bus travel'])[0] == 'Transport'
    assert training.MODEL_PATH.exists()

@pytest.mark.parametrize('text', [
    'Spent ₹100 on food and ₹50 on travel today',
    'Paid 100 for pizza and 50 for a taxi yesterday',
    'Spent ₹300 for lunch and INR 200 for petrol',
])
def test_multiple_amounts_require_correction(text):
    result = parse_entry(text, TODAY)
    assert result['amount'] is None
    assert validate_entry(result)
    assert result['warnings']

@pytest.mark.parametrize('text', [
    'Received salary ₹20000 and spent ₹500 today',
    'I did not spend ₹300 on pizza today',
    "I haven't paid ₹500 for rent today",
    'I never purchased ₹900 shoes today',
])
def test_mixed_or_negated_intent_stays_blank(text):
    assert parse_entry(text, TODAY)['intent'] is None

@pytest.mark.parametrize('text,expected', [
    ('Remind me to pay ₹500 rent tomorrow', 'Reminder'),
    ('Reminder to pay ₹500 electricity bill due tomorrow', 'Reminder'),
    ('SPENT INR 450 ON LUNCH TODAY', 'Expense'),
    ('Recieved Rs 15000 salery today', 'Income'),
    ('unpaid ₹500 internet invoice', None),
])
def test_intent_boundaries_and_typo(text, expected):
    assert parse_entry(text, TODAY)['intent'] == expected

@pytest.mark.parametrize('text,base,expected', [
    ('Reminder ₹500 electricity bill tomorrow', date(2026,12,31), date(2027,1,1)),
    ('Paid ₹50 bus fare yesterday', date(2027,1,1), date(2026,12,31)),
    ('Reminder ₹500 rent on 5 January', date(2026,12,31), date(2027,1,5)),
    ('Reminder ₹500 rent on 29 February 2028', TODAY, date(2028,2,29)),
    ('Reminder ₹500 rent on 29 February 2027', TODAY, None),
    ('Reminder ₹500 rent on 31 April 2027', TODAY, None),
    ('Reminder ₹500 rent on 03/04/2027', TODAY, date(2027,4,3)),
])
def test_calendar_boundaries(text, base, expected):
    assert parse_entry(text, base)['date'] == expected


def test_multiple_dates_stay_blank():
    result = parse_entry('Reminder ₹500 rent tomorrow or next Friday', TODAY)
    assert result['date'] is None
    assert validate_entry(result)


def test_unknown_vocabulary_returns_other():
    assert parse_entry('Spent ₹50 on qzxv jjjxyz today', TODAY)['category'] == 'Other'

@pytest.mark.parametrize('text,expected', [
    ('Paid ₹300 for 2 pizzas today', 300),
    ('Paid 500, for bus travel today', 500),
    ('Paid INR 0.50 for service today', .5),
    ('Paid ₹1,00,000 for rent today', None),
    ('Paid five hundred for bus travel today', None),
    ('Paid ₹12..50 for food today', None),
])
def test_amount_edge_cases(text, expected):
    assert extract_amount(text) == expected


def test_unrecognised_reminder_date_requires_manual_input():
    assert parse_entry('Reminder ₹799 internet bill sometime soon', TODAY)['date'] is None
