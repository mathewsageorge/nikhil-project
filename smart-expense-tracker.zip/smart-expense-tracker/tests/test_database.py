from datetime import date
import pytest
import database as db

@pytest.fixture
def store(tmp_path):
    path = tmp_path / 'test.db'
    db.init_db(path)
    return path

def entry(intent='Expense', amount=300):
    return dict(intent=intent, amount=amount, date=date(2026,10,12), description='pizza lunch', category='Food')

def test_crud_and_persistence(store):
    identity = db.save_entry(entry(), path=store)
    assert db.list_entries(store).iloc[0].amount == 300
    changed = entry(amount=400.25)
    db.save_entry(changed, identity, store)
    db.init_db(store)
    assert db.list_entries(store).iloc[0].amount_paise == 40025
    db.delete_entry(identity, store)
    assert db.list_entries(store).empty

@pytest.mark.parametrize('amount', [0, -5, None, float('nan'), float('inf'), 0.001])
def test_reject_invalid_amount(store, amount):
    with pytest.raises(ValueError):
        db.save_entry(entry(amount=amount), path=store)
    assert db.list_entries(store).empty

def test_invalid_intent_and_missing_due_date(store):
    for record in [dict(entry(), intent=None), dict(entry('Reminder'), date=None)]:
        with pytest.raises(ValueError):
            db.save_entry(record, path=store)
    assert db.list_entries(store).empty

def test_reminder_paid_once_and_delete_reopens(store):
    identity = db.save_entry(entry('Reminder'), path=store)
    assert db.mark_paid(identity, date(2026,10,13), store)
    assert not db.mark_paid(identity, date(2026,10,13), store)
    frame = db.list_entries(store)
    assert len(frame) == 2
    assert db.monthly_summary(frame, '2026-10') == (0,300)
    with pytest.raises(ValueError):
        db.save_entry(entry('Reminder', 500), identity, store)
    linked = int(frame[frame.intent == 'Expense'].iloc[0].id)
    db.delete_entry(linked, store)
    assert db.list_entries(store).iloc[0].paid == 0
    assert db.mark_paid(identity, path=store)

def test_delete_paid_reminder_preserves_expense(store):
    identity = db.save_entry(entry('Reminder'), path=store)
    db.mark_paid(identity, path=store)
    db.delete_entry(identity, store)
    frame = db.list_entries(store)
    assert len(frame) == 1
    assert frame.iloc[0].intent == 'Expense'
    assert frame.iloc[0].source_reminder_id is None

def test_budgets_and_totals(store):
    db.set_budget('2026-10', 1000, store)
    db.set_budget('2026-10', 1200, store)
    assert db.get_budget('2026-10', store) == 1200
    assert db.get_budget('2026-11', store) == 0
    db.save_entry(entry('Expense', .1), path=store)
    db.save_entry(entry('Expense', .2), path=store)
    db.save_entry(entry('Income', 2000), path=store)
    db.save_entry(entry('Reminder', 999), path=store)
    assert db.monthly_summary(db.list_entries(store), '2026-10') == (2000, .3)
    with pytest.raises(ValueError):
        db.set_budget('2026-13', 100, store)

@pytest.mark.parametrize('day,paid,status', [('2026-10-11',0,'Overdue'),('2026-10-12',0,'Due today'),('2026-10-13',0,'Upcoming'),('2026-10-11',1,'Paid')])
def test_reminder_status(day, paid, status):
    assert db.reminder_status(dict(date=day, paid=paid), date(2026,10,12)) == status
