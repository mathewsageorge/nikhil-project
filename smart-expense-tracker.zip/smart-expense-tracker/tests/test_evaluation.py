import pytest
from evaluate_model import audit_datasets, score_model
from train_model import load_model


def test_datasets_are_balanced_and_separate():
    training, evaluation = audit_datasets()
    assert len(training) == 400
    assert len(evaluation) == 100
    assert set(training.category.value_counts()) == {40}
    assert set(evaluation.category.value_counts()) == {10}


def test_overlap_is_rejected(tmp_path):
    training, evaluation = audit_datasets()
    evaluation.loc[0, 'description'] = training.iloc[0].description.upper()
    train_path, eval_path = tmp_path / 'train.csv', tmp_path / 'eval.csv'
    training.to_csv(train_path, index=False)
    evaluation.to_csv(eval_path, index=False)
    with pytest.raises(ValueError, match='overlap'):
        audit_datasets(train_path, eval_path)


def test_evaluation_reports_all_rows_and_classes():
    _, evaluation = audit_datasets()
    metrics, predictions = score_model(load_model(), evaluation)
    assert len(predictions) == 100
    assert sum(map(sum, metrics['confusion_matrix'])) == 100
    assert len(metrics['confusion_matrix']) == 10
    assert 0 <= metrics['accuracy'] <= 1
    assert metrics['classification_report']['Food']['support'] == 10
