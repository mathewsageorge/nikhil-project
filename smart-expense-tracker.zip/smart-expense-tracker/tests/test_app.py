"""Execute real Streamlit widget workflows against isolated SQLite storage."""
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
import database as db

@pytest.fixture
def app(tmp_path, monkeypatch):
    original = db.connection
    monkeypatch.setattr(db, 'connection', lambda path=None: original(tmp_path / 'ui.db'))
    return AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=30).run()


def click(app, label):
    next(button for button in app.button if button.label == label).click().run()
    assert not app.exception


def test_startup_and_full_workflow(app):
    assert not app.exception
    app.text_area(key='sentence').set_value('Spent ₹300 on pizza today')
    click(app, 'Extract details')
    assert next(s for s in app.selectbox if s.label == 'Category').value == 'Food'
    click(app, 'Save transaction')
    assert len(db.list_entries()) == 1
    click(app, 'Edit')
    next(n for n in app.number_input if n.label == 'Amount (₹)').set_value(350)
    click(app, 'Save changes')
    assert db.list_entries().iloc[0].amount == 350
    # AppTest retains closed dialog nodes; reload the page after the dialog closes.
    app = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=30).run()
    app.text_area(key='sentence').set_value('Remind me to pay ₹1200 electricity bill tomorrow')
    click(app, 'Extract details')
    click(app, 'Save transaction')
    click(app, 'Mark paid')
    assert len(db.list_entries()) == 3
    assert db.list_entries().query("intent == 'Reminder'").iloc[0].paid == 1
    assert not app.exception


def test_invalid_preview_can_be_corrected(app):
    app.text_area(key='sentence').set_value('pizza today')
    click(app, 'Extract details')
    click(app, 'Save transaction')
    assert len(db.list_entries()) == 0
    assert app.error
    next(s for s in app.selectbox if s.label == 'Intent').select('Expense')
    next(n for n in app.number_input if n.label == 'Amount (₹)').set_value(250)
    click(app, 'Save transaction')
    assert db.list_entries().iloc[0].amount == 250


def test_reminder_missing_date_never_saves(app):
    app.text_area(key='sentence').set_value('Reminder ₹799 internet bill')
    click(app, 'Extract details')
    assert next(d for d in app.date_input if d.label == 'Date / reminder due date').value is None
    click(app, 'Save transaction')
    assert db.list_entries().empty
    assert app.error


def test_budget_warning_and_delete(app):
    db.save_entry(dict(intent='Expense',amount=500,date=__import__('datetime').date.today(),description='coffee',category='Food'))
    app.run()
    next(n for n in app.number_input if n.label == 'Monthly budget (₹)').set_value(100)
    click(app, 'Save budget')
    assert any('Overspending' in w.value for w in app.warning)
    click(app, 'Edit')
    app.checkbox[0].check()
    click(app, 'Delete selected entry')
    assert db.list_entries().empty


def test_budget_values_follow_selected_month(app):
    from datetime import date
    today = date.today()
    other = date(today.year + 1, 1, 1)
    next(n for n in app.number_input if n.label == 'Monthly budget (₹)').set_value(900)
    click(app, 'Save budget')
    app.date_input(key='month').set_value(other).run()
    assert next(n for n in app.number_input if n.label == 'Monthly budget (₹)').value == 0
    app.date_input(key='month').set_value(today).run()
    assert next(n for n in app.number_input if n.label == 'Monthly budget (₹)').value == 900


def test_ambiguous_amount_cannot_save_until_corrected(app):
    app.text_area(key='sentence').set_value('Spent ₹100 on pizza and ₹50 on taxi today')
    click(app, 'Extract details')
    click(app, 'Save transaction')
    assert db.list_entries().empty
    assert any('single valid amount' in w.value for w in app.warning)
    next(n for n in app.number_input if n.label == 'Amount (₹)').set_value(100)
    click(app, 'Save transaction')
    assert db.list_entries().iloc[0].amount == 100


def test_oversized_amount_stays_invalid_in_preview(app):
    app.text_area(key='sentence').set_value('Spent ₹2000000000 on shopping today')
    click(app, 'Extract details')
    assert next(n for n in app.number_input if n.label == 'Amount (₹)').value == 0
    click(app, 'Save transaction')
    assert db.list_entries().empty


def test_dashboard_cards_update_after_changes(app):
    from datetime import date
    today = date.today()
    db.save_entry(dict(intent='Income', amount=20000, date=today, description='Salary', category='Salary'))
    db.save_entry(dict(intent='Expense', amount=500, date=today, description='Lunch', category='Food'))
    db.set_budget(today.strftime('%Y-%m'), 1000)
    app.run()
    metrics = {m.label: m.value for m in app.metric}
    assert metrics['↗ Total Income'] == '₹20,000.00 INR'
    assert metrics['↘ Total Expenses'] == '₹500.00 INR'
    assert metrics['◈ Current Balance'] == '₹19,500.00 INR'
    assert metrics['▣ Monthly Budget'] == '₹1,000.00 INR'
    assert metrics['◷ Budget Remaining'] == '₹500.00 INR'
    assert any('Budget under control' in m.value for m in app.markdown)


def test_dashboard_reminders_first_and_removed_when_paid(app):
    from datetime import date, timedelta
    assert 'Reminders' not in [h.value for h in app.subheader]
    entry_id = db.save_entry(dict(intent='Reminder', amount=799, date=date.today()-timedelta(days=1), description='<Internet bill>', category='Utilities'))
    app.run()
    headers = [h.value for h in app.subheader]
    assert headers.index('Reminders') < headers.index('Monthly overview')
    assert any('&lt;Internet bill&gt;' in m.value and 'Overdue' in m.value for m in app.markdown)
    db.mark_paid(entry_id)
    app.run()
    assert 'Reminders' not in [h.value for h in app.subheader]
    assert app.metric[1].value == '₹799.00 INR'


def test_budget_near_limit_and_exceeded(app):
    from datetime import date
    today = date.today()
    db.save_entry(dict(intent='Expense', amount=850, date=today, description='Groceries', category='Food'))
    db.set_budget(today.strftime('%Y-%m'), 1000)
    app.run()
    assert any('Approaching your limit' in m.value for m in app.markdown)
    assert any('Budget alert' in w.value for w in app.warning)
    db.set_budget(today.strftime('%Y-%m'), 800)
    app.run()
    assert any('Budget exceeded' in m.value for m in app.markdown)
    assert any('Overspending' in w.value for w in app.warning)


def test_entry_first_and_monthly_plan_in_tab(app):
    assert app.subheader[0].value == 'Add an expense, income, or reminder'
    assert [tab.label for tab in app.tabs] == ['📒 History & edit', '🔔 Bill reminders', '📊 Insights & export', '▣ Monthly plan']
    assert not app.sidebar.number_input
    assert any(n.label == 'Monthly budget (₹)' for n in app.tabs[3].number_input)
    assert app.subheader[1].value == 'Monthly overview'


def test_history_search_filters_and_empty_state(app):
    from datetime import date
    for description, category in [('Lunch [office]', 'Food'), ('Bus travel', 'Transport')]:
        db.save_entry(dict(intent='Expense', amount=100, date=date.today(), description=description, category=category))
    app.run()
    app.text_input(key='history_search').set_value('[office]').run()
    assert any('Lunch [office]' in m.value for m in app.markdown)
    assert not any('Bus travel' in m.value for m in app.markdown)
    app.selectbox(key='history_type').select('Income').run()
    assert any('No matching transactions' in m.value for m in app.info)
    assert not app.exception


def test_history_show_more_and_dialog_edit(app):
    from datetime import date
    for n in range(12):
        db.save_entry(dict(intent='Expense', amount=n+1, date=date.today(), description=f'Lunch {n}', category='Food'))
    app.run()
    assert len([b for b in app.button if str(b.key).startswith('open_history_')]) == 10
    assert not any(n.label == 'Amount (₹)' for n in app.number_input)
    click(app, 'Show more transactions')
    assert len([b for b in app.button if str(b.key).startswith('open_history_')]) == 12
    first = next(b for b in app.button if str(b.key).startswith('open_history_'))
    first.click().run()
    assert any(n.label == 'Amount (₹)' for n in app.number_input)
    next(n for n in app.number_input if n.label == 'Amount (₹)').set_value(42)
    click(app, 'Save changes')
    assert 42 in db.list_entries().amount.values
    app = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=30).run()
    assert not any(n.label == 'Amount (₹)' for n in app.number_input)
    app.text_input(key='history_search').set_value('Lunch 11').run()
    assert len([b for b in app.button if str(b.key).startswith('open_history_')]) == 1
    assert not app.exception


def test_bills_one_list_and_payment_moves_to_completed(app):
    from datetime import date, timedelta
    bill = db.save_entry(dict(intent='Reminder', amount=1200, date=date.today()-timedelta(days=1), description='Electricity', category='Utilities'))
    app.run()
    assert not app.tabs[1].dataframe
    assert any('Overdue' in m.value and 'Electricity' in m.value for m in app.tabs[1].markdown)
    assert not any('Electricity' in m.value for m in app.tabs[0].markdown)
    click(app, 'Mark paid')
    assert not any(b.label == 'Mark paid' for b in app.button)
    assert any(e.label == 'Paid bills (1)' for e in app.expander)
    assert len(db.list_entries().query("intent == 'Expense'")) == 1
    assert db.list_entries().query('id == @bill').iloc[0].paid == 1
